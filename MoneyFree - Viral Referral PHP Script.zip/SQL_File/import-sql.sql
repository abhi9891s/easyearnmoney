-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 16, 2018 at 11:35 AM
-- Server version: 10.1.35-MariaDB-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edrimyid_testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `id` int(11) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`id`, `username`, `password`) VALUES
(1, 'admin', '7a25b0bc04e77a2f7453dd021168cdc2');

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE `advertisements` (
  `id` int(11) NOT NULL,
  `bannercodetop` varchar(999) NOT NULL,
  `bannercodecontent` varchar(999) NOT NULL,
  `bannercodebottom` varchar(999) NOT NULL,
  `headcode` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`id`, `bannercodetop`, `bannercodecontent`, `bannercodebottom`, `headcode`) VALUES
(1, '<img src=\"/assets/img/banner-728x90.png\"/>', '<img src=\"/assets/img/banner-728x90.png\"/>', '<img src=\"/assets/img/banner-728x90.png\"/>', '<!-- Head adcode -->');

-- --------------------------------------------------------

--
-- Table structure for table `cookie_ref`
--

CREATE TABLE `cookie_ref` (
  `REF_id` bigint(254) NOT NULL,
  `REF_val` varchar(254) NOT NULL,
  `REF_hits` int(1) NOT NULL,
  `REF_bal` decimal(6,2) NOT NULL DEFAULT '0.00',
  `REF_last` decimal(6,2) NOT NULL DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cookie_ref`
--

INSERT INTO `cookie_ref` (`REF_id`, `REF_val`, `REF_hits`, `REF_bal`, `REF_last`) VALUES
(409, 'oqczUXU2b', 3, '0.20', '60.00'),
(410, 'uKk7ReIxc', 0, '0.00', '0.00'),
(411, 't7mBReIxc', 0, '0.00', '0.00'),
(412, 'nI1cy6tVb', 0, '0.00', '0.00'),
(413, 'lL1U0z6ab', 0, '0.00', '0.00'),
(414, 'YS6vXQh8', 0, '0.00', '0.00'),
(415, 'mNnssKTKd', 0, '0.00', '0.00'),
(416, '9vr3UXU2b', 0, '0.00', '0.00'),
(417, 'ajAkvDgQc', 0, '0.00', '0.00'),
(418, 'UGPovDgQc', 0, '0.00', '0.00'),
(419, 'Ay4VLssne', 1, '0.10', '0.00'),
(420, 'io4wsKTKd', 0, '0.00', '0.00'),
(421, 'VU3ovDgQc', 0, '0.00', '0.00'),
(422, 'Ge3zXQh8', 0, '0.00', '0.00'),
(423, 'ut3zXQh8', 0, '0.00', '0.00'),
(424, 'ISDsvDgQc', 0, '0.00', '0.00'),
(425, 'rhJZLssne', 0, '0.00', '0.00'),
(426, '6kJROl5sd', 0, '0.00', '0.00'),
(427, 'fCGky6tVb', 0, '0.00', '0.00'),
(428, 'cJH3XQh8', 1350, '50.00', '120.00'),
(429, 'MKIky6tVb', 0, '0.00', '0.00'),
(430, 'B0J0sKTKd', 0, '0.00', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `cookie_ref_ips`
--

CREATE TABLE `cookie_ref_ips` (
  `IP_id` bigint(20) NOT NULL,
  `IP_address` varchar(20) NOT NULL,
  `REF_val` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cookie_ref_ips`
--

INSERT INTO `cookie_ref_ips` (`IP_id`, `IP_address`, `REF_val`) VALUES
(62, '182.1.38.20', 'oqczUXU2b'),
(61, '173.252.87.6', 'Ay4VLssne'),
(60, '173.252.87.7', 'oqczUXU2b'),
(59, '114.125.247.75', 'oqczUXU2b');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `title` varchar(220) NOT NULL,
  `slug` varchar(999) NOT NULL,
  `page` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `page`) VALUES
(1, 'Privacy Policy', 'privacy-policy', '<div><span style=\"font-style: italic;\">Effective date: October 12, 2018</span></div><div><br></div><div>MoneyFree (\"us\", \"we\", or \"our\") operates the http://moneyfree.co website (hereinafter referred to as the \"Service\").</div><div><br></div><div>This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data.</div><div><br></div><div>We use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, the terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from http://moneyfree.co</div><div><br></div><div><span style=\"font-weight: bold; font-size: 24px;\">Information Collection And Use</span></div><div><br></div><div>We collect several different types of information for various purposes to provide and improve our Service to you.</div><div><br></div><div><span style=\"font-size: 18px; font-weight: bold;\">Types of Data Collected</span></div><div><br></div><div><span style=\"font-weight: bold;\">Personal Data</span></div><div><br></div><div>While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (\"Personal Data\"). Personally identifiable information may include, but is not limited to:</div><div><br></div><div><ul><li>Email address<br></li><li>Cookies and Usage Data<br></li></ul></div><div><br></div><div><span style=\"font-weight: bold;\">Usage Data</span></div><div><br></div><div>We may also collect information on how the Service is accessed and used (\"Usage Data\"). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.</div><div><br></div><div><span style=\"font-weight: bold;\">Tracking & Cookies Data</span></div><div><br></div><div>We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.</div><div><br></div><div>Cookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.</div><div><br></div><div>You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service. Please read our <a href=\"http://moneyfree.co/page/cookies-policy\" target=\"_blank\">Â Cookies Policy</a>.</div><div><br></div><div><span style=\"font-weight: bold;\">Use of Data</span></div><div><br></div><div>MoneyFree uses the collected data for various purposes:</div><div><br></div><div><ul><li>To make payment<br></li><li>To provide and maintain the Service<br></li><li>To notify you about changes to our Service<br></li><li>To monitor the usage of the Service<br></li><li>To detect, prevent and address technical issues</li></ul></div><div><br></div><div><span style=\"font-weight: bold;\">Transfer Of Data</span></div><div><br></div><div>Your information, including Personal Data, may be transferred to â€” and maintained on â€” computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.</div><div><br></div><div>If you are located outside Singapore and choose to provide information to us, please note that we transfer the data, including Personal Data, to Singapore and process it there.</div><div><br></div><div>Your consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.</div><div><br></div><div>MoneyFree will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Disclosure Of Data</span></div><div><br></div><div><span style=\"font-weight: bold;\">Legal Requirements</span></div><div><br></div><div>MoneyFree may disclose your Personal Data in the good faith belief that such action is necessary to:</div><div><br></div><div><ul><li>To comply with a legal obligation<br></li><li>To protect and defend the rights or property of MoneyFree<br></li><li>To prevent or investigate possible wrongdoing in connection with the Service<br></li><li>To protect the personal safety of users of the Service or the public<br></li><li>To protect against legal liability<br></li></ul></div><div><br></div><div><span style=\"font-weight: bold;\">Security Of Data</span></div><div><br></div><div>The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 24px;\">Service Providers</span></div><div><br></div><div>We may employ third party companies and individuals to facilitate our Service (\"Service Providers\"), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.</div><div><br></div><div>These third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Analytics</span></div><div><br></div><div>We may use third-party Service Providers to monitor and analyze the use of our Service.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Google Analytics</span></div><div><br></div><div>Google Analytics is a web analytics service offered by Google that tracks and reports website traffic. Google uses the data collected to track and monitor the use of our Service. This data is shared with other Google services. Google may use the collected data to contextualize and personalize the ads of its own advertising network.</div><div><br></div><div>You can opt-out of having made your activity on the Service available to Google Analytics by installing the Google Analytics opt-out browser add-on. The add-on prevents the Google Analytics JavaScript (ga.js, analytics.js, and dc.js) from sharing information with Google Analytics about visits activity.</div><div><br></div><div>For more information on the privacy practices of Google, please visit the Google Privacy & Terms web page: <a href=\"http://policies.google.com/privacy?hl=en\" target=\"_blank\">https://policies.google.com/privacy?hl=en</a></div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Links To Other Sites</span></div><div><br></div><div>Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.</div><div><br></div><div>We have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Children\'s Privacy</span></div><div><br></div><div>Our Service does not address anyone under the age of 18 (\"Children\").</div><div><br></div><div>We do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Changes To This Privacy Policy</span></div><div><br></div><div>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</div><div><br></div><div>We will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the \"effective date\" at the top of this Privacy Policy.</div><div><br></div><div>You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Contact Us</span></div><div><br></div><div>If you have any questions about this Privacy Policy, please <a href=\"http://moneyfree.co/contact\" target=\"_blank\">contact us</a></div>'),
(2, 'FAQ', 'faq', '<div><span style=\"font-weight: bold; font-size: 18px;\">Why do you give free money?</span></div><div><br></div><div>In fact we don\'t give money for free. We need a fee to keep this service available and to pay you. We make money from advertisements on this website. Our income depends on how many people you can invite from your ID URL. We divide half of our income to pay you. This is fair, no one is harmed. This helps us not to cheat you or become a scam.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">How does it work?</span></div><div><br></div><div>When you visit this site, our system will create a special URL ID for you with your browser cookie. This URL ID Â only applies to the browser that you are currently using. You can use this URL ID to invite other people to visit this site, for everyone who visits through your URL ID you will receive a sum of money that you can withdraw through Paypal.</div><div><br></div><div><div><span style=\"font-weight: bold; font-size: 18px;\">How much income do I get?</span></div><div><br></div><div>Nobody knows for sure about this. This depends on how many visitors on your URL ID. We paid <span style=\"font-weight: bold;\">$10</span> for <span style=\"font-weight: bold;\">100</span> visitors. If in a day you can bring <span style=\"font-weight: bold;\">1000</span> visitors then you will be paid <span style=\"font-weight: bold;\">$100/day</span>, or <span style=\"font-weight: bold;\">$1000/week</span> and <span style=\"font-weight: bold;\">$4000/month</span>.</div></div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">When will I get paid?</span></div><div><br></div><div>You will receive payment after your balance reaches a minimum of $25. Payment can only be requested via a Paypal account. Make sure that you have a valid Paypal account.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Do I need to register?</span></div><div><br></div><div>You don\'t like to register and we don\'t want your data. So when you make a withdrawal, we only need your Paypal email address to make payment.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">What happens if I use a proxy or a bot?</span></div><div><br></div><div>Our system always detects any abnormal activity in your ID URL traffic. If we find cheating, we will delete your URL ID including your balance.</div><div><br></div><div><div><span style=\"font-weight: bold; font-size: 18px;\">What happens if I clean my browser cookie?</span></div><div><br></div><div>Be careful. If you clean your browser\'s cookies, then we will reset your URL ID. And this means you will lose your previous URL ID including the balance in it.</div></div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">I need further information, how to contact you?</span><br></div><div><br></div><div>You can contact us via the <a href=\"http://moneyfree.co/contact\" target=\"_blank\">Contact</a> page. We always respond to every question from our users in less than 24 hours.<br></div>'),
(3, 'Terms Of service', 'terms-of-service', '<div>Please read the following terms of use thoroughly. By accessing or using the Site (as defined below) and/or Service (as define below) available through the Site, you hereby agree to be bound contractually by and firmly adhere to these Terms of Use, as they may be amended or supplemented from time to time. If you do not accept these Terms of Use, you may not access the Site and use the Service.</div><div><br></div><div><span style=\"font-weight: bold; font-size: 18px;\">Functionalities</span></div><div><br></div><div><ul><li>The Site and the Service is accessible worldwide to anyone with Internet access.<br></li><li>The Service was designed to allow Visitors to earn money by sharing their URL ID links which are subsequently clicked on.<br></li><li>Users may also get paid by referring a friend to our Site and Service.<br></li><li>The Provider reserves the right to change the Site and Service functionalities at any time, in particular by introducing new functions and facilities for Users.<br></li></ul></div><div><br></div><div><div><span style=\"font-weight: bold; font-size: 18px;\">Conditions for Using the Site and Service and Rules of Liability</span></div><div><br></div><div>1. Technical requirements concerning the use of the Site and the Service are as follows:</div><div><ul><li>Internet connection;<br></li><li>web browser enabling displaying of hypertext documents (HTML) on a computer screen which are linked with the Internet through a website with activated Java Script execution and writing cookies files;<br></li></ul></div></div><div>2. It is User\'s responsibility to ensure that the equipment owned by him as well as the software used meets the above requirements and allow him to use the Site and the Service.<br></div><div><br></div><div>3.Â Before starting the use of the Site and the Service, User is obliged to familiarize himself with the provisions of these Terms of Use and with the Privacy Policy. Access and use of the Site and the Service is equivalent to accepting these Terms of Use and the Privacy Policy.</div><div><br></div><div>4.Â Users undertakes to respect the Terms of Use while using the Site and the Service, both in its current wording and with any later amendments.</div><div><br></div><div>5.Â User undertakes to abstain from any actions that could hinder or destabilize the operation of the Site or use of the Service. The Provider may, without any previous notice, undertake any action available, inclusive of a demand for compensation, as a response to any malicious activities or any other breach of the applicable law or these Terms of Use. Without limitation, the actions referred to in the previous sentence shall be as follows:</div><div><br></div><div><div><ul><li>attempts at disturbing or cutting off access to subscriptions of other Users or to their computers (DOS, DDOS attacks, DNS spoofing);<br></li><li>entering malicious software into the system or onto the computers of the Provider, especially inclusive of viruses, Trojan horses or internet bugs;<br></li><li>pharming, that is the use of malicious software, disturbing the operation of DNS servers or other means aimed at redirecting User to a website or to another site impersonating the Site in order to gather personal data of the User, the data necessary for logging or other information;<br></li><li>taking over IP addresses;<br></li><li>direct or indirect sending of e-mail addresses for the purposes of sending mass unsolicited correspondence (spam).<br></li></ul></div></div><div>Without limiting any other provision in these Terms of Use, User may not use the Site to do the following or assist others to do the following:<br></div><div><br></div><div><div><ul><li>threaten, defame, stalk, abuse or harass other persons or engage in illegal activities;<br></li><li>link to the Site from another website or transmit any material that is inappropriate, profane, vulgar, offensive, false, disparaging, defamatory, obscene, illegal, sexually explicit, racist, that promotes violence, racial hatred, or terrorism, or the Provider deems, in its sole discretion, to be otherwise objectionable;<br></li><li>frame the Site, display the Site in connection with an unauthorized logo or mark, or do anything that could falsely suggest a relationship between the Provider and any third person or potentially deprive the Provider of revenue (including, without limitation, revenue from advertising, branding or promotional activities);<br></li><li>violate any person\'s or entity\'s legal rights (including, without limitation, intellectual property rights or privacy rights), transmit material that violates or circumvents such rights or remove or alter intellectual property or other legal notices;<br></li><li>transmit files that contain viruses, spyware, adware or other harmful code;<br></li><li>advertise or promote goods or services the Provider deems, in its sole discretion, to be objectionable (including, without limitation, by sending spam);<br></li><li>interfere with others using the Site or otherwise disrupt the Site;</li><li>defeat any access controls, access any portion of the Site that the Provider has not authorized User to access.<br></li></ul></div></div><div><br></div><div>User may not use the Service for any illegal or unauthorised purpose. User must not, in the use of the Service, violate any laws in his jurisdiction (including but not limited to copyright laws). In particular, User are prohibited from:<br></div><div><br></div><div><div><ul><li>advertising their MoneyFree ID URL link directly on any form of traffic exchange/PTC website;<br></li><li>placing their MoneyFree ID URL link anywhere that may: (i) contain any types of content that is threatening, harassing, defamatory, obscene, harmful to minors, or contains nudity, pornography or sexually explicit materials; (ii) contain any viruses, Trojan horses, worms, time bombs, cancel bots, or other computer programming routines that are intended to damage, interfere with, surreptitiously intercept or expropriate any system, data, or personal information; (iii) contain software or use technology that attempts to intercept, divert or redirect Internet traffic to or from any other website, or that potentially enables the diversion of User commissions from another website;<br></li><li>offering any incentive for a visitor to click on their MoneyFree ID URL link, including gifts/points/cash;<br></li><li>asking/begging people to click on their MoneyFree ID URL link simply to generate a revenue;<br></li><li>creating \'redirect loops\' to generate a revenue;<br></li><li>spamming with their MoneyFree ID URL link anywhere, including forums/chat/comments/blogs;<br></li><li>participating in click \'rings\' where Users clicks on others links in return for others to click on his MoneyFree ID URL link;<br></li><li>opening MoneyFree ID URL link in a popup / popunder or iframe;<br></li><li>automatically redirecting to websites with JavaScript redirect or meta-refresh (only a HTTP redirect is allowed);<br></li><li>clicking on their MoneyFree ID URL link on their own (User may click on his own URL ID link one time to test it.).<br></li></ul></div></div><div><br></div><div>6.Â Payments from the Provider are made through PayPal. User must have a valid PayPal account to receive a fee, as the Provider does not offer payment via cheque/check, credit card, cash or other method. The minimum amount available for a withdrawal is USD$25.</div><div><br></div><div>7.Â The Provider will only pay for clicks that are automatically tracked and reported by our system. For our system to track the click, the visitor must have cookies enabled. We will not pay fees if the click was not tracked by our system.</div><div><br></div><div>8.Â The Provider reserves the right to disqualify any fees earned through fraudulent, illegal, or overly aggressive, questionable sales or marketing methods.</div><div><br></div><div>9.Â If User is found or reported breaking any of the provisions of these Terms of Use, his URL ID will be removed and all fees forfeited.</div><div><br></div><div>10.Â The Provider is authorized to immediately, without prior notice, terminate an agreement, suspend or permanently remove the access to the Service of the User who breaches these Terms of Use.</div><div><br></div><div>11.Â If the user cannot use the URL ID to invite at least one visitor, then this user URL ID will become inactive (\"Inactive Refferal ID\").Â Inactive referrals will be deleted within a certain time.</div><div><br></div><div><div><span style=\"font-weight: bold; font-size: 18px;\">Intellectual Property</span></div><div><br></div><div><ul><li>The Site and the Service and all rights related thereto are the exclusive property of the Provider or third parties. All creative elements placed on this Site are protected by intellectual property rights, and in particularly by copyright. All trademarks, logos, graphics, photographs, animations, videos, texts and other distinctive signs appearing on the Sites are the intellectual property of the Provider or third parties. Therefore, they may not be reproduced, used or represented without the prior written authorization of the Provider or third parties.<br></li><li>User hereby undertakes to respect intellectual property rights (including author\'s economic rights and industrial property rights, as well as the rights resulting from registration of trademarks) to which the Provider or third parties are entitled.<br></li><li>On the condition that the User complies with all his/her obligations under these Terms of Use, the Provider hereby grants to User a limited, revocable, non-exclusive, non-assignable, non-sublicenseable right to access and to use the Service as the Provider intends the Service to be used, and only in accordance with these Terms of Use. Provider grants to the User no other rights, implied or otherwise. User will not nor will User allow any third party to: (i) copy, modify, adapt, translate or otherwise create derivative works of the Service; (ii) reverse engineer, de-compile, disassemble or otherwise attempt to discover the source code of the Service, except to the extent applicable laws specifically prohibit such restriction; (iii) rent, sublicense, lease, sell, assign or otherwise transfer rights (or purport to do any of the same) in or to the Service; and (iv) use, post, transmit or introduce any device, software or routine which interferes or attempts to interfere with the operation of the Service. User will use the Service solely for his/her own internal use. User will comply with all applicable laws and regulations relating to the use of and access to the Service. User may not provide access to the Service to third parties. The license granted above and User\'s right of use of the Service will terminate immediately if User fails to comply with these Terms of Use.<br></li></ul></div></div><div><br></div><div><br></div>'),
(9, 'Cookies Policy', 'cookies-policy', '<p>Thank you for visiting www.moneyfree.co (\"Website\"). Â This cookie notice applies to the Website, any website or branded pages on third party platforms (e.g. YouTube and Facebook) and applications accessed or used through such websites or platforms which are operated by or on behalf of MoneyFree (\"MoneyFree Site\").</p><p>By using a MoneyFree, you are consenting to our use of cookies and other tracking technology in accordance with this notice. If you do not agree to our use of cookies and other tracking technology in this way, you should set your browser settings accordingly or not use the MoneyFree Site. If you disable cookies that we use, this may impact your user experience while on the MoneyFree Site.</p><p><span style=\"font-weight: bold; font-size: 18px;\">1. What are cookies?</span></p><p>Cookies are small text files that are placed on your computer by websites that you visit. They are widely used in order to make websites work, or work more efficiently, as well as to provide information to the owners of the site.</p><p>See below for details on what information is collected by cookies and how we use that information. For more information about the kind of data we collect, please read ourÂ Â <a href=\"http://moneyfree.co/page/privacy-policy\" target=\"_blank\">Privacy Policy</a>.</p><p><span style=\"font-weight: bold; font-size: 18px;\">2. How and why does MoneyFree use them?</span></p><p>MoneyFree Uses cookies to create unique ID URLs as identifiers for you. We use this cookie to store your activities on our website, for example when you invite someone else to visit this website using your ID URL.</p><p>Cookies help us tailor MoneyFree websites to your personal needs, to improve their user-friendliness, gain customer satisfaction feedback on our websites (through designated partners) and to communicate to you elsewhere on the web.</p><p>MoneyFree keeps all the information collected from cookies in a nonâ€“personally identifiable format. MoneyFree cookies located on your computer do not retain your name or your IP address.</p><p><span style=\"font-weight: bold; font-size: 18px;\">3. What type of cookies does MoneyFree use?</span></p><p>The following types of cookies are used on MoneyFree websites.</p><p><span style=\"font-weight: bold;\">Necessary cookies</span></p><p>These are cookies that are strictly necessary for the operation of a website. Without these cookies, this website wonâ€™t work properly. Accordingly, we are not asking you for your specific consent for those cookies. For all other cookies your informed consent is required.</p><p><span style=\"font-weight: bold;\">Session cookies</span></p><p>Session cookies are temporary cookie files which are erased when you close your browser. When you restart your browser and go back to the site that created that cookie, the website will treat you as a new visitor.</p><p><span style=\"font-weight: bold;\">Functional/Persistent Cookies</span></p><p>These are cookies which are set up to improve the functionality of the website. For example, cookies that remember the content you previously viewed on this website.Â </p><p><span style=\"font-weight: bold;\">Cookies that send information to us</span></p><p>These are the cookies that we set on a MoneyFree Site and they can only be read by that site. This is known as a \"First Party\" cookie.</p><p>We also place cookies on brand ads which are placed on other websites owned by third parties (e.g. Facebook). We obtain information via those cookies when you click on or interact with the advertisement. In this situation the brand is placing a â€œThird Partyâ€ cookie. The brand may use the information obtained by these cookies to serve you with advertising that is relevant and of interest to you based on your past online behaviour.</p><p><span style=\"font-weight: bold;\">Cookies that send information to other companies</span></p><p>These are cookies that are set on a MoneyFree Site by our partner companies (e.g. Facebook or advertisers). They may use the data collected from these cookies to anonymously target advertising to you on other websites, based on your visit to this Website. For example, if you use a social widget (e.g. the Facebook icon) on the Website, it will record your â€œshareâ€ or â€œlikeâ€. Facebook (as the company setting the cookie) will collect the data. This is known as a â€œ<span style=\"font-weight: bold;\">Third Party</span>â€™â€™ cookie.</p><p><span style=\"font-weight: bold;\">Demographics and Interest Reporting</span></p><p>Some of our websites use Google Analytics Demographics and Interest Reporting to improve advertising. Some common applications are to target advertising based on whatâ€™s relevant to a user, to improve reporting on campaign performance, and to avoid showing ads the user has already seen. This is done using something called the DoubleClick cookie. If you donâ€™t want your information collected in this way, you can:</p><p><ul><li>use Googleâ€™s <a href=\"http://www.google.co.uk/ads/preferences\" target=\"_blank\">Ad Settings</a> to opt out of Display Advertising; or<br></li><li>use Google\'s <a href=\"http://tools.google.com/dlpage/gaoptout\" target=\"_blank\">Browser add-on</a> to opt out of Google Analytics<br></li></ul></p><p>DoubleClick cookies contain no personally identifiable information. Sometimes the DoubleClick cookie will contain an additional identifier that is similar in appearance to the cookie ID, and is used to identify an ad campaign to which a user was exposed previously.</p><p>We will not use any information reported by Google Analytics Demographics and Interest Reporting to identify any individual user of our site.</p><p><span style=\"font-weight: bold; font-size: 18px;\">4. How can I change my cookie settings?</span></p><p>Please ensure that your computer setting reflects whether you are happy to accept cookies or not. You can set your browser to warn you before accepting cookies, or you can simply set it to refuse them, although you may not have access to all the features of this website if you do so. See your browser \'help\' button for how you can do this. Remember that if you use different computers in different locations, you will need to ensure that each browser is adjusted to suit your cookie preferences.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `reffid` varchar(15) NOT NULL,
  `paypal` varchar(32) NOT NULL DEFAULT 'no_email@domain.com',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `date` varchar(64) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `reffid`, `paypal`, `amount`, `date`, `status`) VALUES
(70, 'OyMh7hbL2', 'no_email@domain.com', '50.00', 'October 16, 2018', 1),
(71, 'HnBBD22Q0', 'no_email@domain.com', '290.00', 'October 16, 2018', 1),
(72, 'NeSi5hpwn', 'no_email@domain.com', '520.00', 'October 16, 2018', 1),
(74, 'dbfZTx1tU', 'no_email@domain.com', '25.00', 'October 16, 2018', 1),
(75, 'U5qVta6NF', 'no_email@domain.com', '150.00', 'October 16, 2018', 1),
(76, 'tk34II6de', 'no_email@domain.com', '820.00', 'October 16, 2018', 1),
(77, 'kJ8FTlNFd', 'no_email@domain.com', '50.00', 'October 16, 2018', 1),
(78, 'W0RhmOIw5', 'no_email@domain.com', '25.00', 'October 16, 2018', 1),
(79, 'n4LCQZVTU', 'no_email@domain.com', '180.00', 'October 16, 2018', 1),
(80, 'x0UNpBXZh', 'no_email@domain.com', '360.00', 'October 16, 2018', 1),
(81, 'HTSdhciP0', 'no_email@domain.com', '925.00', 'October 16, 2018', 0),
(82, 'GBs6pAmDE', 'no_email@domain.com', '540.00', 'October 16, 2018', 0),
(83, 'cJH3XQh8', 'no_email@domain.com', '120.00', 'October 16, 2018', 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_title` varchar(500) NOT NULL,
  `email` varchar(32) CHARACTER SET utf8mb4 NOT NULL DEFAULT 'support@yoursite.com',
  `site_name` varchar(32) NOT NULL DEFAULT 'MoneyFree.co',
  `logo` varchar(64) NOT NULL,
  `site_link` varchar(999) NOT NULL,
  `meta_keywords` varchar(999) NOT NULL,
  `meta_description` varchar(999) NOT NULL,
  `headtags` varchar(999) CHARACTER SET utf8mb4 NOT NULL,
  `footertags` varchar(999) NOT NULL,
  `fb_app_id` varchar(999) NOT NULL,
  `wd` decimal(6,2) NOT NULL DEFAULT '25.00',
  `rate` decimal(6,2) NOT NULL DEFAULT '0.10',
  `wd_status` int(1) NOT NULL DEFAULT '0',
  `bonus` decimal(6,2) NOT NULL DEFAULT '0.00',
  `link` varchar(120) NOT NULL,
  `site_views` int(11) NOT NULL,
  `version` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_title`, `email`, `site_name`, `logo`, `site_link`, `meta_keywords`, `meta_description`, `headtags`, `footertags`, `fb_app_id`, `wd`, `rate`, `wd_status`, `bonus`, `link`, `site_views`, `version`) VALUES
(1, 'Your Viral Site Title', '', 'MoneyFree', '', '', '', '', '', '', '', '25.00', '0.10', 1, '0.00', 'https://phpscripts.cc', 0, '1.1.0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cookie_ref`
--
ALTER TABLE `cookie_ref`
  ADD PRIMARY KEY (`REF_id`);

--
-- Indexes for table `cookie_ref_ips`
--
ALTER TABLE `cookie_ref_ips`
  ADD PRIMARY KEY (`IP_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cookie_ref`
--
ALTER TABLE `cookie_ref`
  MODIFY `REF_id` bigint(254) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=431;

--
-- AUTO_INCREMENT for table `cookie_ref_ips`
--
ALTER TABLE `cookie_ref_ips`
  MODIFY `IP_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
