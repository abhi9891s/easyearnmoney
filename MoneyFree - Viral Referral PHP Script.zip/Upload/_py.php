<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
error_reporting(E_ALL);
ini_set('display_errors', '1');
include("include/main.php");
if($Bal <$Payout){
 header("location:/");   
}
elseif($Bal >$Payout || $Bal == $Payout) {
$update = 	$mysqli->query("UPDATE cookie_ref SET REF_bal =0.00 WHERE REF_val = '".$ref."'");
		$mysqli->query($update);
	header("location:$WdLink");
}
?>