<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
$Captcha = $_SESSION['captcha']['code'];
include ("db.php");
if($_POST)
{	
    if(!isset($_POST['inputCaptcha']) || strlen($_POST['inputCaptcha'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please enter captcha code!</div>');
	}
    elseif ($_POST['inputCaptcha']!== $Captcha)
    {
     die('<div class="alert alert-danger" role="alert">Incorrect captcha code!</div>');   
    }
    
	if(!isset($_POST['inputYourname']) || strlen($_POST['inputYourname'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please let us know your name.</div>');
	}
	if(!isset($_POST['inputEmail']) || strlen($_POST['inputEmail'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please provide us with a valid email address.</div');
	}
	$email_address = $_POST['inputEmail'];
	
	if (filter_var($email_address, FILTER_VALIDATE_EMAIL)) {
	} else {
  		die('<div class="alert alert-danger" role="alert">Please provide a valid email address.</div>');
	}
	
	if(!isset($_POST['inputSubject']) || strlen($_POST['inputSubject'])<1)
	{
		die('<div class="alert alert-danger" role="alert">inputSubject cannot be blank.</div>');
	}
	if(!isset($_POST['inputMessage']) || strlen($_POST['inputMessage'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Message cannot be blank.</div>');
	}
if($Mail = $mysqli->query("SELECT * FROM settings WHERE id='1'")){
    $SET = mysqli_fetch_array($Mail);
	$Mail->close();
}else{
	 printf("Error: %s\n", $mysqli->error);
}
$SiteContact	 = $SET['email'];
$FromName		 = $mysqli->escape_string($_POST['inputYourname']);
$FromEmail		 = $mysqli->escape_string($_POST['inputEmail']);
$FrominputSubject	 = $mysqli->escape_string($_POST['inputSubject']);
$FromMessage	 = $mysqli->escape_string($_POST['inputMessage']);
require_once('class.phpmailer.php');
$mail             = new PHPMailer(); ;
$mail->AddReplyTo($FromEmail, $FromName);
$mail->SetFrom($FromEmail, $FromName);
$mail->AddReplyTo($FromEmail, $FromName);
$Address = $SET['email'];
$mail->AddAddress($Address, $SiteContact);
$mail->Subject = $FrominputSubject;
$mail->MsgHTML($FromMessage);
if(!$mail->Send()) {?>
<div class="alert alert-danger" role="alert">Error sending mail</div>
<?php } else {?>
<div class="alert alert-success" role="alert">Message sent. We will contact you back as soon as possible.</div>
<?php }
}
?>