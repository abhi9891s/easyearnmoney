<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
$mysqli = new mysqli();
$mysqli->connect('Hostname', 'DBusername', 'Bpassword', 'DBname');

/*
.---------------------------------------------------------------------------.
|                                                                           |
| Hostname - normaly localhost                                              |
| DBusername - your mysql username                                          |
| DBpassword - your mysql password                                          |
| DBname - your mysql database name                                         |
|                                                                           |
'---------------------------------------------------------------------------'
*/

if ($mysqli->connect_errno) { echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error; } 

?>