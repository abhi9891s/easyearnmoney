<?
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
?>
<!DOCTYPE html>
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Title -->
<title><?php echo $PageTitle;?></title>
<!--\ Title -->

<link rel="canonical" href="<?php echo $SiteUrl?>/<?php echo $PageUrl; ?>" />

<!-- Metatags -->
<meta name="description" content="<?php echo $PageDesc;?>" />
<meta name="keywords" content="<?php echo $PageKey;?>" />
<?php if(isset($_GET['ref'])){?>
<meta name="robots" content="noindex, nofollow">
<?php } else {?>
<meta name="robots" content="<?php echo $Bot;?>">
<?php } ?>
<meta property="fb:app_id"          content="<?php echo ($SET['fb_app_id']);?>" /> 
<?php if($phpPage == 'index.php'){?>
<meta property="og:url"             content="<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>" /> 
<?php } else {?>
<meta property="og:url"             content="<?php echo $SiteUrl?>/<?php echo $PageUrl; ?>" /> 
<?php } ?>

<!-- Facebook -->
<meta property="og:type"           content="website" />
<meta property="og:title"           content="<?php echo $PageTitle;?>" />
<meta property="og:description" 	content="<?php echo $PageDesc;?>" /> 
<meta property="og:image"           content="<?php echo $SiteUrl?>/<?php echo $PageImage; ?>" /> 
<!--\ Facebook -->
<!--\ Metatags -->

<!-- Favicon -->
<link rel="apple-touch-icon" sizes="57x57" href="/assets/images/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/images/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/images/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/images/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/images/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/images/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/images/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/images/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/images/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/images/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/images/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<!--\ Favicon -->


<!-- Css -->
<link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/cookie.css" rel="stylesheet">
<link href="/assets/css/social.css" rel="stylesheet">
<link href="/assets/css/default.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<link href="/assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<!--\ Css -->

<!-- Head code & Ads -->
<?php if (!empty($HeadTags)){ ?>
	<?php echo $HeadTags;?>
<?php	} if (!empty($HeadCode)){ ?>
	<?php echo $HeadCode;?>
<?php	}?>
<!--\ Head code & Ads -->
</head>
<body>
<nav class="navbar navbar-light bg-light static-top">
      <div class="container">
       <?php if(empty($Logo)){?>
 <a class="navbar-brand" href="<?php echo $SiteUrl?>"><img src="/assets/images/logo.png" alt="<?php echo $SiteName?>"/></a>
<?php } else {?><a class="navbar-brand" href="<?php echo $SiteUrl?>"><img src="<?php echo $SiteUrl?>/assets/images/<?php echo $Logo?>" alt="<?php echo $SiteName?>"/></a>
<?php } ?>
        <button style="float:right" class="btn btn-primary" data-toggle="modal" data-target="#balance"><i class="fas fa-coins"></i> $<?php echo $Bal;?></a></button>
      </div>
    </nav>
<header class="masthead text-white text-center">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-xl-9 mx-auto">
            <h1>Get Free Money Paypal Instantly</h1>
            <h2>Earn Paypal Extra Cash For Free By Sharing Your Link</h2>
          </div>
          <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
              <div class="form-row">
                <div class="col-12 col-md-9 mb-2 mb-md-0">
                  <input id="copyTarget" type="url" class="form-control form-control-lg" value="<?php echo $SiteUrl?>/<?php echo $referlink; ?>" onclick="this.select()" readonly>
                </div>
                <div class="col-12 col-md-3">
                  <button id="copyButton" class="btn btn-block btn-lg btn-primary">Copy</button>
                </div>
              </div>
              
          </div>
          
        </div>
      </div>
    </header>
<?php if (!empty($BannerCodeTop)){ ?>
<div class="aztop">	<?php echo $BannerCodeTop;?></div>
<?php	}?>    