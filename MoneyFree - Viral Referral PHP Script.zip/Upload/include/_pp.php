<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include('db.php');
include("include/main.php");
if($_POST)
{	
	if(!isset($_POST['inputPaypal']) || strlen($_POST['inputPaypal'])<1)
	{
		die('<div class="alert alert-danger text-center">Please enter a valid Paypal email address!</div>');
	}
	$ValidateEmail = $_POST['inputPaypal'];
	if (filter_var($ValidateEmail, FILTER_VALIDATE_EMAIL)) {
	} else {
  		die('<div class="alert alert-danger text-center">Please enter a valid Paypal email address!</div>');
	}
	$Ref                = $ref;
	$Paypal 			= $mysqli->escape_string($_POST['inputPaypal']);
	$Amount 			= $mysqli->escape_string($_POST['amount']);
	$Date		        = date("F j, Y");
	$Status             = $SET['wd_status'];

	$Payout = $mysqli->query("INSERT INTO payments(reffid, paypal, amount, date, status) VALUES ('$Ref', '$Paypal', '$Amount', '$Date','$Status')");
	$Recent = $mysqli->query("UPDATE cookie_ref SET REF_last = $Amount WHERE REF_val = '".$ref."'");
		$mysqli->query($Recent);	
		
?>
<script type="text/javascript">
function leave() {
window.location = "/py";
}
setTimeout("leave()", 3000);
</script>
<?php		
		die('<div class="alert alert-success text-center">Your withdrawal request has been successfully processed!</div>');
   }else{
   		die('<div class="alert alert-danger">There seems to be a problem. Please try again.</div>');
   } 
?>