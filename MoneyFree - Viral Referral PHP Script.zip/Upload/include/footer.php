<?
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
?>
<div class="modal fade" id="payout">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Error!</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="alert alert-warning" role="alert">
 <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> You are not allowed to make withdraw!
</div>
<p><i class="fa fa-info-circle" aria-hidden="true"></i>  You must reach a minimum balance of <span class="badge badge-success"><i class="fas fa-coins"></i> $<?php echo $Payout;?></span> before submitting your Withdrawal request.</p><p><i class="fa fa-info-circle" aria-hidden="true"></i> Your current balance is: <span class="badge badge-warning"><i class="fas fa-coins"></i> $<?php echo $Bal;?></span></p><i class="fa fa-info-circle" aria-hidden="true"></i> Remaining amount to make withdraw request is: <span class="badge badge-info"><i class="fas fa-coins"></i> $<?php echo $Proc;?></span></p>
<hr/>
<p class="text-center">↓ Copy your referral link below & Invite visitors to get more cash ↓</p><input type="text" class="form-control form-control-lg" value="<?php echo $SET['site_link'];?>/<?php echo $referlink; ?>" onclick="this.select()" /><p class="text-center"><small><i class="far fa-lightbulb"></i> You will receive  $<?php echo $Rec;?> for each 100 visitor</small></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>    

<div class="modal fade" id="balance">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Your URL ID: <i class="fa fa-hashtag" aria-hidden="true"></i><?php echo $ref; ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body"><?php if($Bal <$Payout){?><p><i class="fa fa-info-circle" aria-hidden="true"></i> You currently have balance of <span class="badge badge-success"><i class="fas fa-coins"></i> $<?php echo $Bal;?></span>, after your balance reaches minimum of $<?php echo $Payout;?> you can make  withdrawal to your Paypal account. Remaining balance needed is $<?php echo $Proc;?> or more</p><?php } elseif($Bal >$Payout || $Bal == $Payout) {?>
      <div class="alert alert-success text-center">You have reached the minimum withdrawal threshold. You can request a withdrawal at this time.</div>
      <?php }?>
       <hr/>
<p class="text-center">↓ Copy your referral link below & Invite visitors to get more cash ↓</p><input type="text" class="form-control form-control-lg" value="<?php echo $SET['site_link'];?>/<?php echo $referlink; ?>" onclick="this.select()" /><p class="text-center"><small><i class="far fa-lightbulb"></i> You will receive  $<?php echo $Rec;?> for each 100 visitor</small></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<?php if (!empty($Bannercodebottom)){ ?>
<div class="azbot">	<?php echo $Bannercodebottom;?></div>
<?	}?>    
    <footer class="footer bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
            <ul class="list-inline mb-2">
           
                
                <li class="list-inline-item">
                <a href="<?php echo $SiteUrl?>/page/faq">F.A.Q</a></li>
                 <li class="list-inline-item">
                <a href="<?php echo $SiteUrl?>/page/terms-of-service">Terms Of Service</a></li>
                 <li class="list-inline-item">
                <a href="<?php echo $SiteUrl?>/page/cookies-policy">Cookies Policy</a></li>
                 <li class="list-inline-item">
                <a href="<?php echo $SiteUrl?>/page/privacy-policy">Privacy Policy</a></li>
                <li class="list-inline-item">
                <a href="<?php echo $SiteUrl?>/contact">Contact Us</a></li>
                
                </ul>
            <p class="text-muted small mb-4 mb-lg-0"><i class="far fa-copyright"></i>2018 <?php echo $SiteName;?>, All Rights Reserved.</p>
          </div>
          <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
           <a href="https://startbootstrap.com/template-overviews/landing-page/"
target="_blank">Landing Page</a> Bootstrap 4 Template by   <a href="https://startbootstrap.com/"
target="_blank">StartBootstrap&reg;</a>        </div>
        </div>
      </div>
    </footer>

<script src="/assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/jquery.form.js"></script>
<script>$(document).ready(function() {$('#ContactForm').on('submit',function(e) {e.preventDefault();$('#submitButton').attr('disabled','');$("#output").html('<div class="alert alert-info" role="alert">Working.. Please wait..</div>');$(this).ajaxSubmit({target:'#output',success:afterSuccess});});});$(document).ready(function() {$('#pp').on('submit',function(e) {e.preventDefault();$('#submitButton').attr('disabled','');$("#output").html('<div class="alert alert-info text-center" role="alert">Working.. Please wait..</div>');$(this).ajaxSubmit({target:'#output',success:afterSuccess});});});function afterSuccess() {$('#submitButton').removeAttr('disabled');}</script>
<script type="text/javascript" src="/assets/js/jquery.ihavecookies.js"></script>
<script type="text/javascript">var options={title:'&#x1F36A; Accept Cookies & Privacy Policy',message:'This website uses cookies to store data in your browser and to ensure you get the best experience on our website.',delay:600,expires:30,link:'/page/cookies-policy',onAccept:function(){var myPreferences=$.fn.ihavecookies.cookie();console.log('Yay! The following preferences were saved...');console.log(myPreferences);},uncheckBoxes:true,acceptBtnLabel:'Accept Cookies',moreInfoLabel:'More information',cookieTypesTitle:'Select which cookies you want to accept',fixedCookieTypeLabel:'Essential',fixedCookieTypeDesc:'These are essential for the website to work correctly.'} $(document).ready(function(){$('body').ihavecookies(options);$('#ihavecookiesBtn').on('click',function(){$('body').ihavecookies(options,'reinit');});});</script>
<script type="text/javascript">function copyToClipboard(e){var t,n,o="_hiddenCopyText_",c="INPUT"===e.tagName||"TEXTAREA"===e.tagName;if(c)a=e,t=e.selectionStart,n=e.selectionEnd;else{if(!(a=document.getElementById(o))){var a=document.createElement("textarea");a.style.position="absolute",a.style.left="-9999px",a.style.top="0",a.id=o,document.body.appendChild(a)}a.textContent=e.textContent}var d,l=document.activeElement;a.focus(),a.setSelectionRange(0,a.value.length);try{d=document.execCommand("copy")}catch(e){d=!1}return l&&"function"==typeof l.focus&&l.focus(),c?e.setSelectionRange(t,n):a.textContent="",d}document.getElementById("copyButton").addEventListener("click",function(){copyToClipboard(document.getElementById("copyTarget"))});</script>
<?php if (!empty($FooterTags)){ ?>
	<?php echo $FooterTags;?>
<?	}?>
</body>
</html>