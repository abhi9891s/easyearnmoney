<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
include("db.php");
$phpPage = basename($_SERVER['PHP_SELF']);
$DefaultImage = 'assets/images/og.png';
if($SetSite = $mysqli->query("SELECT * FROM settings WHERE id='1'")){
    $SET = mysqli_fetch_array($SetSite);
    $GetUrl = $SET['site_link'];
    if (!empty($GetUrl)){ 
	$SiteUrl =  $GetUrl;
	}elseif (empty($GetUrl)){
	$SiteUrl =  'http://' . $_SERVER['HTTP_HOST'];
 	}
 	$GetTile = $SET['site_title'];
    if (!empty($GetTile)){ 
	$SiteTitle =  $GetTile;
	}elseif (empty($GetTile)){
	$SiteTitle =  'Welcome!';
 	}
 	$SiteName = $SET['site_name'];
 	$Payout = $SET['wd'];
 	$Rate   = $SET['rate'];
 	$WdLink = $SET['link'];
 	$Logo   = $SET['logo'];
 	$HeadTags = $SET['headtags'];
 	$FooterTags = $SET['footertags'];
 	$Bonus = $SET['bonus'];
	$SetSite->close();
}else{
	 printf("Error: %s\n", $mysqli->error);
}
if($AdSql = $mysqli->query("SELECT * FROM advertisements WHERE id='1'")){
$AdRow = mysqli_fetch_array($AdSql);
	$BannerCodeTop = $AdRow['bannercodetop'];
	$BannerCodeContent = $AdRow['bannercodecontent'];
	$Bannercodebottom = $AdRow['bannercodebottom'];
	$HeadCode          = $AdRow['headcode'];
    $AdSql->close();
}else{
	   printf("Error: %s\n", $mysqli->error);
}
$UpdateSiteViews = $mysqli->query("UPDATE settings SET site_views=site_views+1 WHERE id=1");

if($phpPage == 'index.php'){

  $PageTitle =  $SiteName.' - '.$SiteTitle;
  $PageUrl   = '';
  $Bot       = 'index,follow';
  $PageDesc  = $SET['meta_description'];
  $PageKey   = $SET['meta_keywords'];
  $PageImage = $DefaultImage;
}

elseif($phpPage == 'page.php'){
  if(isset($_GET['slug'])){
$slug = $mysqli->escape_string($_GET['slug']);
if($PageSql = $mysqli->query("SELECT title, slug, page FROM pages WHERE slug='$slug'")){
        $PageRow = mysqli_fetch_array($PageSql);
	    $TitlePage = $PageRow['title'];
		$ContentPage = $PageRow['page'];
		$CutContentPage = strlen ($ContentPage);
	if ($CutContentPage > 300) {
	$ContentPageDesc = substr($ContentPage,0,300).'...';
	}else{
	$ContentPageDesc = $ContentPage;}
		$PageSlug = $PageRow['slug'];
	    $PageSql->close();
}else{
	 printf("Error: %s\n", $mysqli->error);
}
}
  $PageTitle =  $TitlePage.' - '.$SiteName;
  $PageUrl   = 'page/'.$PageSlug;
  $Bot       = 'index,follow';  
  $PageDesc  = strip_tags($ContentPageDesc);
  $PageKey   = $SET['meta_keywords'];
  $PageImage = $DefaultImage;
}
elseif($phpPage == 'ct.php'){
  $PageTitle =  'Contact Us - '.$SiteName;
  $PageUrl   = 'contact';
  $Bot       = 'index,follow';  
  $PageDesc  = 'Contact Us';
  $PageKey   = $SET['meta_keywords'];
  $PageImage = $DefaultImage;
}
elseif($phpPage == 'pyt.php'){
  $PageTitle =  'Requesting a Withdrawal - '.$SiteName;
  $PageUrl   = 'payout';
  $Bot       = 'noindex,nofollow';  
  $PageDesc  = 'Payout';
  $PageKey   = $SET['meta_keywords'];
  $PageImage = $DefaultImage;
}
$error="";
function rand_uniqid($in, $to_num = false, $pad_up = false, $passKey = null)
{
    $index = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if ($passKey !== null) {
        for ($n = 0; $n<strlen($index); $n++) {
            $i[] = substr( $index,$n ,1);
        }
        $passhash = hash('sha256',$passKey);
        $passhash = (strlen($passhash) < strlen($index))
            ? hash('sha512',$passKey)
            : $passhash;
        for ($n=0; $n < strlen($index); $n++) {
            $p[] =  substr($passhash, $n ,1);
        }
        array_multisort($p,  SORT_DESC, $i);
        $index = implode($i);
    }
    $base  = strlen($index);
    if ($to_num) {
        $in  = strrev($in);
        $out = 0;
        $len = strlen($in) - 1;
        for ($t = 0; $t <= $len; $t++) {
            $bcpow = bcpow($base, $len - $t);
            $out   = $out + strpos($index, substr($in, $t, 1)) * $bcpow;
        }
        if (is_numeric($pad_up)) {
            $pad_up--;
            if ($pad_up > 0) {
                $out -= pow($base, $pad_up);
            }
        }
        $out = sprintf('%F', $out);
        $out = substr($out, 0, strpos($out, '.'));
    } else {
        if (is_numeric($pad_up)) {
            $pad_up--;
            if ($pad_up > 0) {
                $in += pow($base, $pad_up);
            }
        }
        $out = "";
        for ($t = floor(log($in, $base)); $t >= 0; $t--) {
            $bcp = bcpow($base, $t);
            $a   = floor($in / $bcp) % $base;
            $out = $out . substr($index, $a, 1);
            $in  = $in - ($a * $bcp);
        }
        $out = strrev($out);
    }
    return $out;
}
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
if(isset($_COOKIE['ref_link'])){
	$ref = $_COOKIE['ref_link'];
	   $getref =	$mysqli->query("SELECT * FROM cookie_ref WHERE REF_val = '$ref'");
	   	$getref_query = 	$getref;
	   		if(mysqli_num_rows($getref_query) < 1){
		$ref = rand(1,9).date('Y').date('m').date('d').date('h').date('i').date('s');
	$ref = rand_uniqid($ref);
	setcookie("ref_link",$ref, 9999999999);  
	$mysqli->query("INSERT INTO cookie_ref(REF_val,REF_bal) VALUES ('$ref','$Bonus')");
	   		}
}else{
	$ref = rand(1,9).date('Y').date('m').date('d').date('h').date('i').date('s');
	$ref = rand_uniqid($ref);
	setcookie("ref_link",$ref, 9999999999);  
	$mysqli->query("INSERT INTO cookie_ref(REF_val,REF_bal) VALUES ('$ref','$Bonus')");
	
}
if(isset($_GET['ref'])){
    $checkref = $mysqli->query("SELECT * FROM cookie_ref WHERE REF_val = '".$_GET['ref']."'");
    $getref_query = 	$checkref;
    if(mysqli_num_rows($getref_query) < 1){
    	$error = '<div class="alert alert-danger text-center" role="alert"><i class="fa fa-exclamation-triangle"></i> Sorry - This referral link has been deleted! We have made another referral link instead.</div>';    
    }
    else {
	$getip =	$mysqli->query("SELECT * FROM cookie_ref_ips WHERE IP_address = '".getRealIpAddr()."' and REF_val = '".$_GET['ref']."'");
	$getip_query = 	$getip;
	if(mysqli_num_rows($getip_query) < 1){
	$update = 	$mysqli->query("UPDATE cookie_ref SET REF_hits = REF_hits + 1, REF_bal = REF_bal + ".$Rate." WHERE REF_val = '".$_GET['ref']."'");
		$mysqli->query($update);
	
	$insertip = 	$mysqli->query("INSERT INTO cookie_ref_ips(IP_address,REF_val) values('".getRealIpAddr()."','".$_GET['ref']."')");
		$mysqli->query($insertip);
	}else{
		$error = '<div class="alert alert-danger text-center" role="alert"><i class="fa fa-exclamation-triangle"></i> Ooops Sorry! You already used this referral link. Limit is Once per Person!!!!</div>';
	}
}
}
if($Sq = $mysqli->query("SELECT * FROM cookie_ref WHERE REF_val = '$ref'")){
          $HitRow = mysqli_fetch_array($Sq);
          $hits=  $HitRow['REF_hits'];
          $Bal= $HitRow['REF_bal'];
          $lPayout = $HitRow['REF_last'];
$Sq->close();
}else{
     printf("Error: %s\n", $mysqli->error);
}
$referlink = '?ref='.$ref;
$Proc   = $Payout - $Bal;
$Rec    = ($Rate) * 100;
$percent = ( $Bal / $Payout ) * 100;
$setpercentOne = substr($percent,0,2);
$setpercent = str_replace('.','', $setpercentOne);
$textpercentOne = substr($percent,0,2);
$textpercent = str_replace('.','', $textpercentOne);
?>