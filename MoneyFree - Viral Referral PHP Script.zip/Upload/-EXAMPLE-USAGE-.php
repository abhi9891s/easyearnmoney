<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
// Require
include("include/main.php");

// Referral Config
$minVisit ='50'; // How many people must be invited before taking action
$percentHits = ( $hits / $minVisit ) * 100; // Calculate percentages
$setpercentHits = substr($percentHits,0,2); // Cut if it exceeds 100%
$setpercentHits = str_replace('.','', $setpercentHits); // Removing dot (.)


// Meta Config
  $PageTitle ='Congratulations! You are chosen as the Samsung Galaxy S8 prize winner!'; // Title for this page
  $PageUrl   ='example-usage'; // Url for this page. eg: example
  $Bot       ='noindex, nofollow'; // Meta robots content
  $PageDesc  =''; // Page Description
  $PageKey   =''; // Page Keywords
  $PageImage =''; // Og Image

?>
<!DOCTYPE html>
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Title -->
<title><?php echo $PageTitle;?></title>
<!--\ Title -->

<link rel="canonical" href="<?php echo $SiteUrl?>/<?php echo $PageUrl; ?>" />

<!-- Metatags -->
<meta name="description" content="<?php echo $PageDesc;?>" />
<meta name="keywords" content="<?php echo $PageKey;?>" />
<?php if(isset($_GET['ref'])){?>
<meta name="robots" content="noindex, nofollow">
<?php } else {?>
<meta name="robots" content="<?php echo $Bot;?>">
<?php } ?>
<meta property="fb:app_id"          content="<?php echo ($SET['fb_app_id']);?>" /> 
<meta property="og:url"             content="<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>" /> 

<!-- Facebook -->
<meta property="og:type"           content="website" />
<meta property="og:title"           content="<?php echo $PageTitle;?>" />
<meta property="og:description" 	content="<?php echo $PageDesc;?>" /> 
<meta property="og:image"           content="<?php echo $SiteUrl?>/<?php echo $PageImage; ?>" /> 
<!--\ Facebook -->
<!--\ Metatags -->

<!-- Favicon -->
<link rel="apple-touch-icon" sizes="57x57" href="/assets/images/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/images/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/images/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/images/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/images/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/images/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/images/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/images/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/images/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/images/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/images/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<!--\ Favicon -->


<!-- Css -->
<link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/cookie.css" rel="stylesheet">
<link href="/assets/css/social.css" rel="stylesheet">
<link href="/assets/css/default.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<link href="/assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<!--\ Css -->

<!-- Head code & Ads -->
<?php if (!empty($HeadTags)){ ?>
	<?php echo $HeadTags;?>
<?php	} if (!empty($HeadCode)){ ?>
	<?php echo $HeadCode;?>
<?php	}?>
<!--\ Head code & Ads -->
</head>
<body>
    
<!-- Section Start -->
<section class="content text-left">
<div class="container">
<div class="row">
<div class="col-lg-12">

<div class="card text-center">
  <div class="card-header">
    <h3>Congratulations! You are chosen as the Samsung Galaxy S8 prize winner!</h3>
  </div>
  <div class="card-body"> 
  
  <!-- Showing Error message -->
  <?php echo $error; ?>
  <!--\ Displaying Error message -->
  
    <h5 class="card-title">Invite <?php echo $minVisit;?> people to get Samsung Galaxy $8 for free!</h5>
    <p class="card-text">You can invite <?php echo $minVisit;?> people by sharing the referral link below ↓</p> <!-- Simple Social Share -->
 <div class="social-share">
 <!-- Facebook Share Button -->
<a target="_blank" class="btns facebook" href="https://facebook.com/sharer.php?t=<?php echo $PageTitle;?>&u=<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>"><i class="fab fa-facebook-f"></i> Share</a>
<!-- Twitter Share Button -->
<a target="_blank" class="btns twitter" href="https://twitter.com/intent/tweet?text=<?php echo $PageTitle;?>&url=<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>"><i class="fab fa-twitter"></i> Tweet</a>
<!-- Googple Plus Share Button -->
<a target="_blank" class="btns gplus" href="https://plus.google.com/share?url=<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>"><i class="fab fa-google-plus-g"></i> Share</a>
</div>
    <input type="text" class="form-control text-center" value="<?php echo $SiteUrl?>/<?php echo $referlink; ?>" onclick="this.select()"/>
   <div id="progress" class="graph"><div id="bar" style="width:<?php if($percentHits < 100){?><?php echo $setpercentHits;?><?php } else { ?>100<?php }?>%"><p><span class="percent"><?php if($percentHits < 100){?><?php echo $setpercentHits;?><?php } else { ?>100<?php }?>%</span> completed...</p></div></div>
   <p>
   <?php if($hits <$minVisit){?>
   <a href="#"  class="btn btn-primary btn-block" data-toggle="modal" data-target="#winprize">Get your prize</a>
   <?php } elseif($hits >$minVisit  || $hits == $minVisits) {?>
   <a href="<?php echo $WdLink;?>"  class="btn btn-primary btn-block">Get your prize</a>
   <?php }?>
   
   </p> <p>You have invited <span class="badge badge-success"><?php echo $hits;?></span> people's</p>
   <p><small>After you invite <?php echo $minVisit;?> people, you are reserve the right to get this prize.</small></p>
  </div>
  <div class="card-footer text-muted">
    &copy; 2018
  </div>
</div>

</div>
</div>
</div>
</div>
</section>
<!--\ Section End -->


<!-- Footer -->
<div class="modal fade" id="winprize">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="alert alert-warning" role="alert">
 <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Please invite <?php echo $minVisit;?> or more people before taking your prize!
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>    

<!--\ Modal -->


<script src="/assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ihavecookies.js"></script>
<script type="text/javascript">var options={title:'&#x1F36A; Accept Cookies & Privacy Policy',message:'This website uses cookies to store data in your browser and to ensure you get the best experience on our website.',delay:600,expires:30,link:'/page/cookies-policy',onAccept:function(){var myPreferences=$.fn.ihavecookies.cookie();console.log('Yay! The following preferences were saved...');console.log(myPreferences);},uncheckBoxes:true,acceptBtnLabel:'Accept Cookies',moreInfoLabel:'More information',cookieTypesTitle:'Select which cookies you want to accept',fixedCookieTypeLabel:'Essential',fixedCookieTypeDesc:'These are essential for the website to work correctly.'} $(document).ready(function(){$('body').ihavecookies(options);$('#ihavecookiesBtn').on('click',function(){$('body').ihavecookies(options,'reinit');});});</script>
<?php if (!empty($FooterTags)){ ?>
	<?php echo $FooterTags;?>
<?	}?>
</body>
</html> 