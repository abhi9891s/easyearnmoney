<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("include/main.php");
if($Bal <$Payout){
 header("location:/");   
} elseif($Bal >$Payout || $Bal == $Payout) {
include("include/header.php");

?>
<section class="content text-left">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="clearfix"></div>
<div class="row">
<div class="col-md-8" style="margin-bottom:3em;">
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Requesting a Withdrawal</h5>
    <p class="card-text">Your balance: <span class="badge badge-warning"><i class="fas fa-coins"></i> $<?php echo $Bal;?></span><br/>Available for withdrawal: <span class="badge badge-success"><i class="fas fa-coins"></i> $<?php echo $Bal;?></span></p><p>* PayPal is the default payout method.In order to successfully receive your payouts via PayPal, Make sure your PayPal email address is fully functional / PayPal account with no pending issues.</p><p>* If you ever encounter any problems or have a question feel free to <a href="/contact">contact us</a>.</p>
    <form id="pp" action="_pp.php" method="post">
    <div class="form-group">
<h6>Paypal ID:</h6>
<input type="hidden" name="amount" id="amount" value="<?php echo $Bal;?>"/>
<input type="text" class="form-control text-center" name="inputPaypal" id="inputPaypal" placeholder="Your PayPal email address">
</div>
<div id="output"></div>
    <button type="submit" id="submitButton" class="btn btn-primary btn-block">  Withdraw ($<?php echo $Bal;?>)</button>
    </form><p class="text-center"><small>The payment process can take 1-2 days. Usually under 1 hour. <br/>If within 3 days you haven't received payment please contact us.</small></p>
  </div>
</div>
</div>
<div class="col-md-4">
<?php include ('_ucp.php');?>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<?php } include("include/footer.php");?>