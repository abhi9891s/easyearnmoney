<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("include/main.php");
include("include/header.php");
?>
<section class="content text-left">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="clearfix"></div>
<div class="row">
<div class="col-md-8" style="margin-bottom:3em;"><h4><?php echo $TitlePage;?></h4>
	<?php echo $ContentPage;?>	
</div>
<div class="col-md-4">
<?php include ('_ucp.php');?>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<?php include("include/footer.php");?>