<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Administrator";
$Query = "administrator";
include("act/_header.php");
include("act/_main.php");
?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Administrator</h2>   
                        Manage your administrator credentials
                    </div>
                </div>              
                  <hr />
                <div class="row">
                    <div class="col-md-8"> 
<form id="credentialsForm" action="act/_admin.php" method="post">
<div class="form-group">
        <label for="inputUsername">Username:</label>
    <div class="input-group">
         <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
      <input type="text" id="inputUsername" name="inputUsername" class="form-control" placeholder="Enter administrator username" value="<?php echo $AdminRow['username']?>">
    </div>
</div>
<div class="form-group">
            <label for="inputCurrentPassword">Current Password:</label>
                <div class="input-group">
                   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
<input type="password" class="form-control" name="inputCurrentPassword" id="inputCurrentPassword" placeholder="Enter Your Current Password">
</div>
</div>
<div class="form-group">
            <label for="inputPassword">New Password:</label>
                <div class="input-group">
                   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
<input type="password" class="form-control" name="inputPassword" id="inputPassword" placeholder="Enter New Password">
</div>
</div>
<div class="form-group">
            <label for="inputConfirmPassword">Confirm Password:</label>
                <div class="input-group">
                   <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
<input type="password" class="form-control" name="inputConfirmPassword" id="inputConfirmPassword" placeholder="Retype New Password">
</div>
</div>
<div id="output"></div>
<button type="submit" id="submitButton" class="btn btn-default btn-success  pull-right"><i class="fa fa-floppy-o" aria-hidden="true"></i> Update &amp; Save</button>
</form>
</div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>