<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Advertisements";
$Query = "advertisements";
include("act/_header.php");
include("act/_main.php");
?>
<div id="page-wrapper" >
 <div id="page-inner">
<div class="row">
<div class="col-md-12">
<h2>Advertisements</h2>Update website advertisements</div>
</div>              
<hr />
<div class="row">
<div class="col-md-8"> <div class="alert alert-warning" role="alert">
  You can input HTML, JavaScript, etc code to the head or footer HTML of your pages. It should be noted that invalid code may prevent some browsers from opening your site, so be careful!
</div>
<form id="adsForm" action="act/_ad.php" method="post">
<div class="form-group">
<label for="bannercodetop">HTML/JavaScript Ad:</label>
<textarea class="form-control" id="bannercodetop" name="bannercodetop" rows="3" placeholder="(728 x 90) or Responsive advertisement code"><?php echo $AdRow['bannercodetop']?></textarea>
</div>
<div class="form-group">
<label for="bannercodecontent">HTML/JavaScript Ad:</label>
<textarea class="form-control" id="bannercodecontent" name="bannercodecontent" rows="3" placeholder="(300 x 250) or Responsive advertisement code"><?php echo $AdRow['bannercodecontent']?></textarea>
</div>
<div class="form-group">
<label for="bannercodebottom">HTML/JavaScript Ad:</label>
<textarea class="form-control" id="bannercodebottom" name="bannercodebottom" rows="3" placeholder="(728 x 90) or Responsive advertisement code"><?php echo $AdRow['bannercodebottom']?></textarea>
</div>
<div class="form-group">
<label for="headcode">JavaScript Ad:</label>
<textarea class="form-control" id="headcode" name="headcode" rows="3" placeholder="Popup ad code. This will be inserted before &lt;/ head&gt;"><?php echo $AdRow['headcode']?></textarea>
</div>
<div id="output"></div>
<button type="submit" id="submitButton" class="btn btn-default btn-success pull-right"><i class="fa fa-floppy-o" aria-hidden="true"></i> Update &amp; Save</button>
</form>
</div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>