<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Make payment";
include("act/_header.php");?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Make payment</h2>   
                       Make fake payments.
                    </div>
                </div>              
                  <hr />
                <div class="row">
                    <div class="col-md-8"> <div id="output"></div>
<form name="randform" id="AdPayout" action="act/_payout.php" enctype="multipart/form-data" method="post"><script language="javascript" type="text/javascript">
function randomRefferal() {
	var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var string_length = 9;
	var randomstring = '';
	for (var i=0; i<string_length; i++) {
		var rnum = Math.floor(Math.random() * chars.length);
		randomstring += chars.substring(rnum,rnum+1);
	}
	document.randform.inputRefferal.value = randomstring;
}
function randomAmount() {
	var chars = "0123456789";
	var string_length = 2;
	var randomstring = '';
	for (var i=0; i<string_length; i++) {
		var rnum = Math.floor(Math.random() * chars.length);
		randomstring += chars.substring(rnum,rnum+1);
	}
	document.randform.inputAmount.value = randomstring;
}
</script>
<div class="form-group">
<label for="inputRefferal">Refferal ID:</label>
<input style="clear:both;margin-bottom:1em;display:block" class="btn btn-info btn-sm" type="button" value="Random" onClick="randomRefferal();"/>
<input type="text" class="form-control" name="inputRefferal" id="inputRefferal" placeholder="Enter referral ID. max.9. eg: tzJlOl5sd" value="">
</div>
<div class="form-group">
<label for="inputPaypal">Paypal ID:</label>
<input type="email" class="form-control" name="inputPaypal" id="inputPaypal" placeholder="Enter referral ID. max.9. eg: tzJlOl5sd" value="no_email@domain.com">
</div>
<div class="form-group">
<label for="inputAmount">Amount:</label>
<input style="clear:both;margin-bottom:1em;display:block" class="btn btn-info btn-sm" type="button" value="Random" onClick="randomAmount();"/>
<input type="text" class="form-control" name="inputAmount" id="inputAmount" placeholder="Enter payment amount. eg. 25" value="">
</div>


<div class="form-group">
<label for="inputStatus">Status:</label>
<select class="form-control" id="inputStatus" name="inputStatus">
<option value="1">Success!</option>
<option value="0">Pending</option>
</select> 
</div>
<div id="output"></div> 
<button type="submit" id="submitButton" class="btn btn-default btn-success  pull-right"><i class="fa fa-plus-circle" aria-hidden="true"></i> Make Payment</button>
</form>
 </div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>