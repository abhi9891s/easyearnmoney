<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
if(isset($_POST['id'])){
foreach ($_POST['id'] as $id):
		$DeleteReff = $mysqli->query("DELETE FROM cookie_ref WHERE REF_id='$id'");
		endforeach;
header('location:/panel/norefferal.php');
}
else{
header('location:/panel/norefferal.php');
	}
?>