<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");

if($_POST)
{	

		if(!isset($_POST['inputWd']) || strlen($_POST['inputWd'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please set the minimum payout amount!</div>');
	}
	if(!isset($_POST['inputRate']) || strlen($_POST['inputRate'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please set the rate per visitor!</div>');
	}
	if(!isset($_POST['inputLink']) || strlen($_POST['inputLink'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please enter a redirect link after request a payout!</div>');
	}
	$Link               = $mysqli->escape_string($_POST['inputLink']);
	$Wd                 = $mysqli->escape_string($_POST['inputWd']);
	$Rate               = $mysqli->escape_string($_POST['inputRate']);
	$Bonus              = $mysqli->escape_string($_POST['inputBonus']);	
	$Status             = $mysqli->escape_string($_POST['inputStatus']);	

  $mysqli->query("UPDATE settings SET wd='$Wd',rate='$Rate',link='$Link',bonus='$Bonus',wd_status='$Status' WHERE id=1");
		die('<div class="alert alert-success" role="alert">Refferal config updated successfully.</div>');
   }else{
   		die('<div class="alert alert-danger" role="alert">There seems to be a problem. please try again.</div>');
}
?>