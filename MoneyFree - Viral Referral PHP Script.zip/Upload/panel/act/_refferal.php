<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
$del = $mysqli->escape_string($_POST['id']);
if($IpId = $mysqli->query("SELECT * FROM cookie_ref WHERE REF_id='$del'")){
    $GetInfo = mysqli_fetch_array($IpId);
	$DelIp   = $GetInfo['REF_val'];
	$IpId->close();
}else{
	 printf("Error: %s\n", $mysqli->error);
}
if($Ip = $mysqli->query("SELECT * FROM cookie_ref_ips WHERE REF_val='$DelIp'")){
    $GetInfo = mysqli_fetch_array($Ip);
	$CountIp = mysqli_num_rows($Ip);
	$Ip->close();
}else{
	 printf("Error: %s\n", $mysqli->error);
}
if ($CountIp>0){
$DeleteIp = $mysqli->query("DELETE FROM cookie_ref_ips WHERE REF_val='$DelIp'");
}
$DeleteReff = $mysqli->query("DELETE FROM cookie_ref WHERE REF_id='$del'");
echo '<div class="alert alert-success" role="alert">Refferal ID successfully deleted</div>';
?>