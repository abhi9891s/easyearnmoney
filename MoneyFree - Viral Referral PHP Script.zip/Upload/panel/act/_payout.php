<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
if($_POST)
{	
	if(!isset($_POST['inputRefferal']) || strlen($_POST['inputRefferal'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please add a prize title!</div>');
	}
	if(!isset($_POST['inputAmount']) || strlen($_POST['inputAmount'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please enter prize description</div>');
	}

	$ReffId			= $mysqli->escape_string($_POST['inputRefferal']);
	$PaypalId			= $mysqli->escape_string($_POST['inputPaypal']);
	$Status			    = $mysqli->escape_string($_POST['inputStatus']);
	$Amount    = $mysqli->escape_string($_POST['inputAmount']);
	$AddedOn			= date("F j, Y");
		$mysqli->query("INSERT INTO payments(reffid, paypal, amount, date, status) VALUES ('$ReffId','$PaypalId', '$Amount','$AddedOn','$Status')");
?>
<script>
$('#AddPayout').delay(500).resetForm(500);
$('#AddPayout').delay(1000).slideUp(1000);
</script>
<?php
		die('<div class="alert alert-success" role="alert">Your payment submitted successfully.</div>');
   }
   else{
   		die('<div class="alert alert-danger" role="alert">There seems to be a problem. please try again.</div>');
   
}
?>