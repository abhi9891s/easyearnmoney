<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("_count.php");?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
     <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $PageTitle;?> - Admin . Panel</title>
    <link href="<?php echo $SET['site_link'];?>/panel/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo $SET['site_link'];?>/panel/assets/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo $SET['site_link'];?>/panel/assets/css/custom.css" rel="stylesheet" />
    <link rel="icon" type="image/x-icon" href="<?php echo $SET['site_link'];?>/panel/assets/img/favicon.ico" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <script src="<?php echo $SET['site_link'];?>/panel/assets/js/jquery.min.js"></script>
   <script src="<?php echo $SET['site_link'];?>/panel/assets/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="<?php echo $SET['site_link'];?>/panel/assets/js/jquery.form.js"></script>
   <script src="<?php echo $SET['site_link'];?>/panel/assets/js/main.js"></script>
   <link href="<?php echo $SET['site_link'];?>/panel/assets/css/summernote.css" rel="stylesheet">
   <script src="<?php echo $SET['site_link'];?>/panel/assets/js/summernote.min.js"></script>
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/panel">Admin . Panel</a> 
            </div>
  <div style="color: white;padding: 15px 50px 5px 5px;float: right;font-size: 16px;">  <a href="logout.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a> </div><div style="color: white;padding: 15px 0px 5px 50px;float: right;font-size: 16px;">  <a href="<?php echo $SET['site_link'];?>" class="btn btn-success square-btn-adjust" target="_blank"><i class="fa fa-eye" aria-hidden="true"></i> View site</a> </div>
        </nav> 
<?php include("_navigation_menu.php");?>      
        