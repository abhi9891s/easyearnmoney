<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
$UploadDirectory	= '../../assets/images/';
if (!@file_exists($UploadDirectory)) {
	die('<div class="alert alert-danger">Make sure Upload directory exist!</div>');
}
if($_POST)
{	
	if(!isset($_POST['inputTitle']) || strlen($_POST['inputTitle'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please enter your site title!</div>');
	}
		if(!isset($_POST['inputName']) || strlen($_POST['inputName'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please enter your site Name!</div>');
	}

	if(!isset($_POST['inputSiteurl']) || strlen($_POST['inputSiteurl'])<1)
	{
		die('<div class="alert alert-danger" role="alert">Please enter your site link!</div>');
	}
	$SiteTitle			= $mysqli->escape_string($_POST['inputTitle']);
	$SiteName			= $mysqli->escape_string($_POST['inputName']);
	$SiteLink           = $mysqli->escape_string($_POST['inputSiteurl']);
	$SiteEmail		    = $mysqli->escape_string($_POST['inputEmail']);	
	$FBApp       		= $mysqli->escape_string($_POST['inputFbapp']);	
	$MetaDescription    = $mysqli->escape_string($_POST['inputDescription']);
	$MetaKeywords 		= $mysqli->escape_string($_POST['inputKeywords']);
	$HeadTags 		    = $mysqli->escape_string($_POST['inputHeadTags']);
	$FooterTags 		= $mysqli->escape_string($_POST['inputFooterTags']);
	if(isset($_FILES['inputfile']))
	{
	if($_FILES['inputfile']['error'])
	{
		die(upload_errors($_FILES['inputfile']['error']));
	}
	$Logo				= strtolower($_FILES['inputfile']['name']); 
	$ImageExt			= substr($Logo, strrpos($Logo, '.'));
	$FileType			= $_FILES['inputfile']['type'];
	$FileSize			= $_FILES['inputfile']["size"];
	switch(strtolower($FileType))
	{
		case 'image/png':
			break;
		default:
			die('<div class="alert alert-danger" role="alert">Unsupported File! Please upload PNG file as your logo.</div>');
	}
	$NewLogoName = 'logo'.$ImageExt;
   if(move_uploaded_file($_FILES['inputfile']["tmp_name"], $UploadDirectory . $NewLogoName ))
   {
	$mysqli->query("UPDATE settings SET site_title='$SiteTitle',site_name='$SiteName',logo='$NewLogoName'site_link='$SiteLink',email='$SiteEmail',meta_keywords='$MetaKeywords',meta_description='$MetaDescription'fb_app_id='$FBApp',headtags='$HeadTags',footertags='$FooterTags' WHERE id=1");
	}	
   }else{ 
  $mysqli->query("UPDATE settings SET site_title='$SiteTitle',site_name='$SiteName',site_link='$SiteLink',email='$SiteEmail',meta_keywords='$MetaKeywords',meta_description='$MetaDescription',fb_app_id='$FBApp',headtags='$HeadTags',footertags='$FooterTags' WHERE id=1");
   
    }
		die('<div class="alert alert-success" role="alert">Site settings updated successfully.</div>');
   }else{
   		die('<div class="alert alert-danger" role="alert">There seems to be a problem. please try again.</div>');
}

if(isset($_FILES['inputfile']))
	{
function upload_errors($err_code) {
	switch ($err_code) { 
        case UPLOAD_ERR_INI_SIZE: 
            return 'The uploaded file exceeds the upload_max_filesize directive in php.ini'; 
        case UPLOAD_ERR_FORM_SIZE: 
            return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form'; 
        case UPLOAD_ERR_PARTIAL: 
            return 'The uploaded file was only partially uploaded'; 
        case UPLOAD_ERR_NO_FILE: 
            return 'No file was uploaded'; 
        case UPLOAD_ERR_NO_TMP_DIR: 
            return 'Missing a temporary folder'; 
        case UPLOAD_ERR_CANT_WRITE: 
            return 'Failed to write file to disk'; 
        case UPLOAD_ERR_EXTENSION: 
            return 'File upload stopped by extension'; 
        default: 
            return 'Unknown upload error'; 
    } 
} 
	}
?>