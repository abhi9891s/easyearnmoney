<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
include("_writeurl.php");
if($_POST)
{	
	$id = $mysqli->escape_string($_GET['id']);
	if(!isset($_POST['inputTitle']) || strlen($_POST['inputTitle'])<1)
	{
		die('<div class="alert alert-danger">Please enter desired page title.</div>');
	}
	if(!isset($_POST['inputDescription']) || strlen($_POST['inputDescription'])<1)
	{
		die('<div class="alert alert-danger">Please enter description for your page.</div>');
	}
	$PageTitle			= $mysqli->escape_string($_POST['inputTitle']);
	$PageLink           = CleanUrl($PageTitle);	
	$PageDescription	= $mysqli->escape_string($_POST['inputDescription']);
	$mysqli->query("UPDATE pages SET title='$PageTitle', slug='$PageLink', page='$PageDescription' WHERE id='$id'");
		die('<div class="alert alert-success" role="alert">Page updated successfully.</div>');
   }else{
   	
		die('<div class="alert alert-danger" role="alert">There seems to be a problem. please try again.</div>');
}
?>