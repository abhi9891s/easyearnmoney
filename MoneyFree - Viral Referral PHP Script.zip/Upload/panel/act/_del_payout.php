<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
$del = $mysqli->escape_string($_POST['id']);
$DeletePayment = $mysqli->query("DELETE FROM payments WHERE id='$del'");
echo '<div class="alert alert-success" role="alert">Payment successfully deleted!</div>';
?>