<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
if($PayoutNumber = $mysqli->query("SELECT id FROM payments")){
    
               $TotalPayout = $PayoutNumber->num_rows;
$PayoutNumber->close();
	          }
	          else{
         	 printf("Error: %s\n", $mysqli->error);
               }
if($CompletedPayout = $mysqli->query("SELECT id FROM payments WHERE status=1")){

    $CompletedPayoutNumber = $CompletedPayout->num_rows;

    $CompletedPayout->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}
if($PendingPayout = $mysqli->query("SELECT id FROM payments WHERE status=0")){

    $PendingPayoutNumber = $PendingPayout->num_rows;

    $PendingPayout->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

if($PagesId = $mysqli->query("SELECT id FROM pages")){
                $TotalPage= $PagesId->num_rows;
 $PagesId->close();
	         }else{
        	 printf("Error: %s\n", $mysqli->error);
             }  
if($RefererId = $mysqli->query("SELECT REF_id FROM cookie_ref")){
                $TotalReferer= $RefererId->num_rows;
 $RefererId->close();
	         }else{
        	 printf("Error: %s\n", $mysqli->error);
             }  
if($ActiveRefererId = $mysqli->query("SELECT REF_id FROM cookie_ref WHERE REF_hits !='0'")){
                $ActiveReferer= $ActiveRefererId->num_rows;
 $ActiveRefererId->close();
	         }else{
        	 printf("Error: %s\n", $mysqli->error);
             }  
 if($NoActiveRefererId = $mysqli->query("SELECT REF_id FROM cookie_ref WHERE REF_hits ='0'")){
                $NoActiveReferer= $NoActiveRefererId->num_rows;
 $NoActiveRefererId->close();
	         }else{
        	 printf("Error: %s\n", $mysqli->error);
             }             
?>