<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
include("_writeurl.php");
if($_POST)
{	
	if(!isset($_POST['inputTitle']) || strlen($_POST['inputTitle'])<1)
	{
		die('<div class="alert alert-danger">Please enter desired page title.</div>');
	}
	if(!isset($_POST['inputDescription']) || strlen($_POST['inputDescription'])<1)
	{
		die('<div class="alert alert-danger">Please enter description for your new page.</div>');
	}
	$PageTitle			= $mysqli->escape_string($_POST['inputTitle']);
	$PageLink           = CleanUrl($PageTitle);	
	$CheckPage = $PageLink ;
	if($PageCheck = $mysqli->query("SELECT * FROM pages WHERE slug ='$CheckPage'")){
   	$CheckRow = mysqli_fetch_array($PageCheck);
	$PageExists = $CheckRow['slug'];
   	$PageCheck->close();
	}else{
     printf("Error: %s\n", $mysqli->error);
	}
		if ($PageExists)
	{
		die('<div class="alert alert-danger">Page Title Exists! Please try another.</div>');
	}
	$PageDescription	= $mysqli->escape_string($_POST['inputDescription']);
	$mysqli->query("INSERT INTO pages(title, slug, page) VALUES ('$PageTitle', '$PageLink', '$PageDescription')");
		die('<div class="alert alert-success" role="alert">New page added successfully.</div>');
   }else{
		die('<div class="alert alert-danger" role="alert">There seems to be a problem. please try again.</div>');
}
?>