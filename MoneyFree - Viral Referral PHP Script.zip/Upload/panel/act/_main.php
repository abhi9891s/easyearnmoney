<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
$phpPage = basename($_SERVER['PHP_SELF']);
if($phpPage == 'ad.php'){
if($Ads = $mysqli->query("SELECT * FROM $Query")){
    $AdRow = mysqli_fetch_array($Ads);
    $Ads->close();
}else{
	 printf("Error: %s\n", $mysqli->error);
}
}
elseif($phpPage == 'admin.php'){
if($GetAdmin = $mysqli->query("SELECT * FROM $Query WHERE id='1'")){
    $AdminRow = mysqli_fetch_array($GetAdmin);
    $GetAdmin->close();
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}
}
elseif($phpPage == 'editpage.php'){
if($Pages = $mysqli->query("SELECT * FROM $Query WHERE id='$id'")){

    $EditPageRow = mysqli_fetch_array($Pages);
	
    $Pages->close();
	
}else{
	 printf("Error: %s\n", $mysqli->error);
}
}
?>