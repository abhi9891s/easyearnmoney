<?
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
?>
<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <a  href="/panel"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                       <li>
                        <a><i class="fa fa-cog" aria-hidden="true"></i> Settings <span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level">
                    <li  >
                        <a   href="set.php"><i class="fa fa-globe" aria-hidden="true"></i> Site Settings</a>
                    </li>
                    <li  >
                        <a   href="ref-config.php"><i class="fa fa-gears" aria-hidden="true"></i> Refferal Config</a>
                    </li>
					 <li  >
                        <a   href="ad.php"><i class="fa fa-code" aria-hidden="true"></i> Advertisements</a>
                    </li>	
                     <li  >
                        <a   href="admin.php"><i class="fa fa-key" aria-hidden="true"></i> Administrator</a>
                    </li>	
					 </ul>
                      </li> 
                    <li>
                        <a><i class="fa fa-bookmark" aria-hidden="true"></i> Pages <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="newpage.php"><i class="fa fa-plus-circle" aria-hidden="true"></i> Create Page</a>
                            </li>
                            <li>
                                <a href="pages.php"><i class="fa fa-folder-open" aria-hidden="true"></i> All Pages <span class="badge" style="float:right;"><?php echo $TotalPage;?></span></a>
                            </li>
                        </ul>
                      </li>  
                  <li  >
                      <li>
                        <a><i class="fa fa-paypal" aria-hidden="true"></i> Payments <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                          <li>
                        <a  href="payment.php"><i class="fa fa-plus-circle" aria-hidden="true"></i> Make Payment</a>
                    </li>  <li  >
                        <a   href="payments.php"><i class="fa fa-check" aria-hidden="true"></i> Completed <span class="badge" style="float:right;"><?php echo $CompletedPayoutNumber;?></span></a>
                    </li>	
                      <li  >
                        <a  href="pending.php"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Pending <span class="badge" style="float:right;"><?php echo $PendingPayoutNumber;?></span></a>
                    </li></ul></li>
                      
                     <li>
                        <a><i class="fa fa-user" aria-hidden="true"></i> Refferal ID  <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                     <li  >
                        <a  href="refferal.php"><i class="fa fa-exchange" aria-hidden="true"></i> Active Refferal <span class="badge" style="float:right;"><?php echo $ActiveReferer;?></span></a>
                    </li>
                     <li  >
                        <a  href="norefferal.php"><i class="fa fa-exchange" aria-hidden="true"></i> Inactive Refferal <span class="badge" style="float:right;"><?php echo $NoActiveReferer;?></span></a>
                    </li></ul></li>
                    </ul>
            </div>
</nav>  