<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(!isset($_SESSION['adminuser'])){
	header("location:login.php");
}
include("../../include/db.php");
if($_POST)
{	
	$bannercodetop			= $mysqli->escape_string($_POST['bannercodetop']);
	$bannercodecontent		= $mysqli->escape_string($_POST['bannercodecontent']);
	$bannercodebottom			= $mysqli->escape_string($_POST['bannercodebottom']);
	$headcode			= $mysqli->escape_string($_POST['headcode']);
	$mysqli->query("UPDATE advertisements SET bannercodetop='$bannercodetop',bannercodecontent='$bannercodecontent',bannercodebottom='$bannercodebottom',headcode='$headcode' WHERE id=1");
		die('<div class="alert alert-success" role="alert">Site advertisements updated successfully.</div>');
   }else{
		die('<div class="alert alert-danger" role="alert">There seems to be a problem. please try again.</div>');
}
?>