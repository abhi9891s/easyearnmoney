<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Refferal Config";
include("act/_header.php");
?>
<div id="page-wrapper" >
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h2>Refferal Config </h2>Update Refferal Config</div>
</div>              
<hr />
<div class="row">
<div class="col-md-8"> 
<form id="refForm" action="act/_refconf.php" enctype="multipart/form-data" method="post">

<div class="form-group">
<label for="inputLink">Redirect link:</label>
<div class="alert alert-info" role="alert">
  Enter a redirect link after request a payout. You can enter affiliate links, CPA/CPI offers links, Direct Ad links and whatever links you like.
</div>
<div class="input-group"><span class="input-group-addon"><span class="glyphicon fa  fa-link"></span></span><input type="url" class="form-control" name="inputLink" id="inputLink" placeholder="http://" value="<?php echo $SET['link']?>"></div>
</div>

<div class="form-group">
<label for="inputRate">Rate per Visit:</label>
<div class="alert alert-info" role="alert">
  What is the rate per visitor who visits the referral link. Default is: 0.10<br/> This means that the referral link owner will receive $10 per 100 visitors.
</div>
<div class="input-group"><span class="input-group-addon"><span class="glyphicon fa  fa-paypal"></span></span><input type="text" class="form-control" name="inputRate" id="inputRate" placeholder="25" value="<?php echo $SET['rate']?>"></div>
</div>
<div class="form-group">
<label for="inputBonus">Welcome Bonus :</label>
<div class="alert alert-info" role="alert">
  If you want to give a bonus to every new user who accesses the site, set the bonus amount here or leave it standard.
</div>
<div class="input-group"><span class="input-group-addon"><span class="glyphicon fa  fa-paypal"></span></span><input type="text" class="form-control" name="inputBonus" id="inputBonus" placeholder="0.00" value="<?php echo $SET['bonus']?>"></div>
</div>
<div class="form-group">
<label for="inputWd">Minimum Payout Amount:</label>
<div class="input-group"><span class="input-group-addon"><span class="glyphicon fa  fa-paypal"></span></span><input type="text" class="form-control" name="inputWd" id="inputWd" placeholder="25" value="<?php echo $SET['wd']?>"></div>
</div>
<div class="form-group">
<label for="inputStatus">Default status for withdrawal requests:</label>
<select class="form-control" id="inputCategory" name="inputStatus">
  <option value="1">Success</option>
    <option value="0">Pending</option>
</select> 
</div>
<div id="output"></div>
<button type="submit" id="submitButton" class="btn btn-default btn-success  pull-right"><i class="fa fa-floppy-o" aria-hidden="true"></i> Update</button>
</form></div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>