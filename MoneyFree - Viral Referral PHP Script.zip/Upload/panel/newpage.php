<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Add Page";
include("act/_header.php");?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Add Page</h2>   
                        Add New Page
                    </div>
                </div>              
                  <hr />
                <div class="row">
                    <div class="col-md-8"> 
<form id="AddPageForm" action="act/_newpage.php" method="post">
<div class="form-group">
        <label for="inputTitle">Page Title:</label>
    <div class="input-group">
         <span class="input-group-addon"><span class="glyphicon fa  fa-info"></span></span>
      <input type="text" id="inputTitle" name="inputTitle" class="form-control" placeholder="Enter your page title" >
    </div>
</div>
<script>
$(function(){
$('#inputDescription').summernote({
  height: 300,	
  toolbar: [
    
    ['style', ['bold', 'italic', 'underline', 'clear']],
    ['fontsize', ['fontsize']],
    ['para', ['ul', 'ol', 'paragraph']],
    ['height', ['height']],
	['insert', ['link', 'picture']],
	['video', ['video']]
  ]
});
});//]]> </script>
<div class="form-group">
<label for="inputDescription">Page Content:</label>
<textarea class="form-control" id="inputDescription" name="inputDescription" rows="10" placeholder="Your Page Content"></textarea>
</div>
<div id="output"></div> 
<button type="submit" id="submitButton" class="btn btn-default btn-success  pull-right"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Page</button>
</form>
</div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>