<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
ob_start();
if(isset($_SESSION['adminuser'])){
	header("location:index.php");}
include("../include/db.php");
if(!isset($_SESSION['adminuser'])){
if($_POST)
{	$username =	$mysqli->escape_string($_POST['inputUsername']); 
	$password = $mysqli->escape_string($_POST['inputPassword']);
	$gpassword=md5($password);
	if($UserCheck = $mysqli->query("SELECT * FROM administrator WHERE username ='$username' and password ='$gpassword'")){
   	$VdUser = mysqli_fetch_array($UserCheck);
	$Count= mysqli_num_rows($UserCheck);
   	$UserCheck->close();
	}else{
     printf("Error: %s\n", $mysqli->error);
	}
	if ($Count == 1)
	{
	$_SESSION["adminuser"] = $username;
?>
<script type="text/javascript">
function leave() {
  window.location = "/panel";
}
setTimeout("leave()", 1000);
</script>
<?php
	die('<div class="alert alert-success" role="alert">Login You on. Please Wait...</div>');
   }else{die('<div class="alert alert-danger" role="alert">Wrong username or password.</div>');   
   } }
}
ob_end_flush();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin . Login</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link rel="icon" type="image/x-icon" href="<?php echo $SET['site_link'];?>/panel/assets/img/favicon.ico" />   
   <script src="assets/js/jquery.min.js"></script>
   <script src="assts/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="assets/js/jquery.form.js"></script>
   <script src="assets/js/main.js"></script>
</head>
<body>
    <div class="container">
        <div class="row text-center ">
            <div class="col-md-12">
                <br /><br />
                <h2>Admin . Login</h2>
                 <br />
            </div>
        </div>
         <div class="row ">
                  <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                        <strong>   Enter Details To Login </strong>  
                            </div>
                            <div class="panel-body">
                                <div id="output"></div>
                                    <form id="LoginForm" action="login.php" method="post">
                                       <br />
                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
                                            <input type="text" class="form-control" name="inputUsername" id="inputUsername" placeholder="Your Username " />
                                        </div>
                                          <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="fa fa-lock"  ></i></span>
                                            <input type="password" class="form-control" name="inputPassword" id="inputPassword" placeholder="Your Password" />
                                        </div>
                                    <button type="submit" id="submitButton" class="btn btn-danger pull-right">Login</button>
                                    </form>
                            </div>
                        </div>
                    </div>
        </div>
    </div>
        </div>
    <script src="assets/js/jquery.metisMenu.js"></script>
    <script src="assets/js/custom.js"></script>
</body>
</html>