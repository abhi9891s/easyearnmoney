<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Edit Page";
$Query = "pages";
$id = $mysqli->escape_string($_GET['id']);
include("act/_header.php");
include("act/_main.php");
?>
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Edit Page</h2>   
                        Edit Your Site Page
                    </div>
                </div>              
                  <hr />
                <div class="row">
                    <div class="col-md-8"> 
  <form id="EditPageForm" action="act/_edit_page.php?id=<?php echo $id;?>" method="post">
<div class="form-group">
        <label for="inputTitle">Page Title:</label>
    <div class="input-group">
         <span class="input-group-addon"><span class="glyphicon fa  fa-info"></span></span>
      <input type="text" id="inputTitle" name="inputTitle" class="form-control" placeholder="Edit Page" value="<?php echo $EditPageRow['title'];?>">
    </div>
</div>
<script>
$(function(){
$('#inputDescription').summernote({
  height: 300,	
  toolbar: [
    
    ['style', ['bold', 'italic', 'underline', 'clear']],
    ['fontsize', ['fontsize']],
    ['para', ['ul', 'ol', 'paragraph']],
    ['height', ['height']],
	['insert', ['link', 'picture']],
	['video', ['video']]
  ]
});
});//]]> </script>
<div class="form-group">
<label for="inputDescription">Page Content:</label>
<textarea class="form-control" id="inputDescription" name="inputDescription" rows="3" placeholder="Your page content"><?php echo $EditPageRow['page'];?></textarea>
</div>
<div id="output"></div> 
<button type="submit" id="submitButton" class="btn btn-default btn-success  pull-right"><i class="fa fa-floppy-o" aria-hidden="true"></i> Update &amp; Save</button>
</form>
</div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>