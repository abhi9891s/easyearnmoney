<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("act/_config.php");
$PageTitle = "Dashboard";
include("act/_header.php");?>
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Admin Dashboard</h2>   
                      <h5>Your website dashboard</h5>  
                    </div>
                </div>              
                  <hr />
                <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-paypal" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $TotalPayout;?></p>
                    <p class="text-muted">Payments</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-4 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-green set-icon">
                    <i class="fa fa-exchange" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $TotalReferer;?></p>
                    <p class="text-muted">Refferal ID</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-4 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-red set-icon">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $SET['site_views'];?>
                    <p class="text-muted">Page Views</p>
                </div>
             </div>
		     </div>
			</div>
                <hr />                
                <div class="row">
                   <div  class="col-md-8">
<h3><button type="button" class="btn btn-primary btn-circle"><i class="fa fa-paypal" aria-hidden="true"></i> </button> Last Completed Payments</h3>
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover">
<?php
$q= $mysqli->query("SELECT * FROM payments WHERE status=1 ORDER BY id DESC LIMIT 10");
	$numr = mysqli_num_rows($q);
	if ($numr==0)
	{
	echo '<div class="alert alert-danger">There are no payments to display at this moment.</div>';
	}
	if ($numr>0)
	{
	?>
        <thead>
            <tr>
				<th>Date</th>
                <th>Refferal ID</th>
                <th>Amount</th>
                <th>Status</th>
            </tr>
        </thead>
<tbody>
    <?php
	}
	while($Row=mysqli_fetch_assoc($q)){
	$Date	= $Row['date'];
	$ReffId = $Row['reffid'];
	$Amount = $Row['amount'];
	$Stat = $Row['status'];
	$Status = str_replace('1', 'Success', $Stat)
?>        
<tr class="btnDelete" data-id="<?php echo $Row['id'];?>">
<td><?php echo $Date;?></td>
<td><?php echo $ReffId;?></td>
<td> <i class="fa fa-paypal" aria-hidden="true"></i> $<?php echo $Amount;?></td>
<td><span class="badge badge-success bg-color-green"><?php echo $Status;?></span></td>
</tr>
<?php } ?>
</tbody></table></div></div><div  class="col-md-4"><div class="table-responsive"><table class="table table-striped table-bordered table-hover">
<h3><button type="button" class="btn btn-info btn-circle"><i class="fa fa-exchange" aria-hidden="true"></i></button> Last 10 Refferal</h3>
<?php
$RefDB= $mysqli->query("SELECT * FROM cookie_ref ORDER BY REF_id DESC LIMIT 10");
	$RefRows = mysqli_num_rows($RefDB);
	if ($RefRows==0)
	{
	echo '<div class="alert alert-danger">There are no refferal id to display at this moment.</div>';
	}
	if ($RefRows>0)
	{
	?>
	<thead><tr><th>Referral ID</th><th>Hits</th><th>Balance</th></tr></thead><tbody>
    <?php
	}
	while($RefResults = mysqli_fetch_assoc($RefDB)){
	$Ref = $RefResults['REF_val'];
	$Hits = $RefResults['REF_hits'];
	$Bal = $RefResults['REF_bal'];
	
?>        
<tr class="btnDelete" data-id="<?php echo $RefResults['id'];?>"><td><a href="<?php echo $SET['site_link'];?>/?ref=<?php echo $Ref;?>" target="_blank"><?php echo $Ref;?></a></td>
<td><?php echo $Hits;?></td><td> <i class="fa fa-paypal" aria-hidden="true"></i> <?php echo $Bal;?> $</td></tr>
<?php } ?>
</tbody></table></div></div></div></div></div>
<?php include("act/_footer.php");?>