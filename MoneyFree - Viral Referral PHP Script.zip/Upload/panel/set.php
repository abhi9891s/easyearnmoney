<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Website Settings";
include("act/_header.php");
?>
<div id="page-wrapper" >
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h2>Site Settings </h2>Update your website settings</div>
</div>              
<hr />
<div class="row">
<div class="col-md-8"> 
<form id="settingsForm" action="act/_set.php" enctype="multipart/form-data" method="post">
<div class="form-group">
<label for="inputfile">Website Logo:</label>
<input type="file" id="inputfile" name="inputfile" class="form-control-file"/>
</div>
<div class="form-group">
        <label for="inputName">Site Name:</label>
    <div class="input-group">
         <span class="input-group-addon"><span class="glyphicon fa  fa-info"></span></span>
      <input type="text" id="inputName" name="inputName" class="form-control" placeholder="Enter your site name, eg. Google" value="<?php echo $SET['site_name']?>">
    </div>
</div>
<div class="form-group">
        <label for="inputTitle">Website Title:</label>
    <div class="input-group">
         <span class="input-group-addon"><span class="glyphicon fa  fa-info"></span></span>
      <input type="text" id="inputTitle" name="inputTitle" class="form-control" placeholder="Enter your site title here" value="<?php echo $SET['site_title']?>">
    </div>
</div>
        


<div class="form-group">
        <label for="inputSiteurl">Website URL:</label><br/><small> (Without trailing slash at end of url, eg. http://yoursite.com)</small>
    <div class="input-group">
         <span class="input-group-addon"><span class="glyphicon fa  fa-link"></span></span>
      <input type="url" id="inputSiteurl" name="inputSiteurl" class="form-control" placeholder="http://yoursite.com" value="<?php echo $SET['site_link']?>">
    </div>
</div>

<div class="form-group">
        <label for="inputEmail">Site Email:</label>
    <div class="input-group">
         <span class="input-group-addon"><span class="glyphicon fa fa-envelope-o"></span></span>
      <input type="email" id="inputEmail" name="inputEmail" class="form-control" placeholder="support@yourdomain.com" value="<?php echo $SET['email']?>">
    </div>
</div>

<div class="form-group">
        <label for="inputFbapp">Facebook App ID:</label>
                <div class="input-group">
                    <span class="input-group-addon"><span class="fa fa-facebook-square"></span></span>
                    <input type="text" id="inputFbapp" name="inputFbapp" class="form-control" placeholder="Enter your facebook app id" value="<?php echo $SET['fb_app_id']?>">
                </div>
</div>
<div class="form-group">
<label for="inputDescription">Meta Description:</label>
<textarea class="form-control" id="inputDescription" name="inputDescription" rows="3" placeholder="Enter a meta description for your website"><?php echo $SET['meta_description']?></textarea>
</div>
<div class="form-group">
<label for="inputKeywords">Meta Keywords:</label>
<textarea class="form-control" id="inputKeywords" name="inputKeywords" rows="3" placeholder="Enter a meta keywords for your website"><?php echo $SET['meta_keywords']?></textarea>
</div>

<hr/><h2>Additional code snippets</h2><div class="alert alert-warning" role="alert">
  You can input HTML, JavaScript, etc code to the head or footer HTML of your pages. It should be noted that invalid code may prevent some browsers from opening your site, so be careful!
</div>
<div class="form-group">
<label for="inputHeadTags">Head section :</label>
<textarea class="form-control" id="inputHeadTags" name="inputHeadTags" rows="3" placeholder="HTML/Javascript/CSS, Meta verification code, etc"><?php echo $SET['headtags']?></textarea>
</div>
<div class="form-group">
<label for="inputFooterTags">Footer section :</label>
<textarea class="form-control" id="inputHeadTags" name="inputFooterTags" rows="3" placeholder="HTML/Javascript/CSS, Meta verification code, etc"><?php echo $SET['footertags']?></textarea>
</div>
<div id="output"></div>
<button type="submit" id="submitButton" class="btn btn-default btn-success  pull-right"><i class="fa fa-floppy-o" aria-hidden="true"></i> Update</button>
</form></div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>