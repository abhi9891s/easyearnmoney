<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
include("act/_config.php");
$PageTitle = "Completed Payments";
include("act/_header.php");?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Manage Payments</h2>   
                        <h5>Manage completed payments</h5>
                    </div>
                </div>              
                  <hr />
                <div class="row">
<script type="text/javascript">$(document).ready(function(){$('button.btnDelete').on('click',function(e){e.preventDefault();var id=$(this).closest('tr').data('id');$('#myModal').data('id',id).modal('show')});$('#btnDelteYes').click(function(){var id=$('#myModal').data('id');var dataString='id='+id;$('[data-id='+id+']').remove();$('#myModal').modal('hide');$.ajax({type:"POST",url:"act/_del_payout.php",data:dataString,cache:!1,success:function(html)
{$("#output").html(html)}})});$('button.btnDisapprove').on('click',function(e){e.preventDefault();var id=$(this).closest('tr').data('id');$('#DisapproveModal').data('id',id).modal('show')});$('#btnDisapproveYes').click(function(){var id=$('#DisapproveModal').data('id');var dataString='id='+id;$('[data-id='+id+']').remove();$('#DisapproveModal').modal('hide');$.ajax({type:"POST",url:"act/_pending_payout.php",data:dataString,cache:!1,success:function(html)
{$("#output").html(html)}})})})</script>
<div class="col-md-8">
<div id="output"></div> 
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover"> 
<?php
error_reporting(E_ALL ^ E_NOTICE);
	$adjacents = 5;
	$query = $mysqli->query("SELECT COUNT(*) as num FROM payments WHERE status=1 ORDER BY id DESC");
	$total_pages = mysqli_fetch_array($query);
	$total_pages = $total_pages['num'];
	$targetpage = "payments.php";
	$limit = 12; 
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 
	else
		$start = 0;	
	$result = $mysqli->query("SELECT * FROM payments  WHERE status=1 ORDER BY id DESC LIMIT $start, $limit");
	if ($page == 0) $page = 1;
	$prev = $page - 1;
	$next = $page + 1;
	$lastpage = ceil($total_pages/$limit);
	$lpm1 = $lastpage - 1;
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<ul class=\"pagination pagination-sm\">";
		if ($page > 1) 
			$pagination.= "<li><a href=\"$targetpage?page=$prev\">&laquo;</a></li>";
		else
			$pagination.= "<li class=\"disabled\"><a href=\"#\">&laquo;</a></li>";	
		if ($lastpage < 7 + ($adjacents * 2))
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<li class=\"active\"><a href=\"#\">$counter</a></li>";
				else
					$pagination.= "<li><a href=\"$targetpage?page=$counter\">$counter</a></li>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))
		{
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<li class=\"active\"><a href=\"#\">$counter</a></li>";
					else
						$pagination.= "<li><a href=\"$targetpage?page=$counter\">$counter</a></li>";					
				}
				$pagination.= "...";
				$pagination.= "<li><a href=\"$targetpage?page=$lpm1\">$lpm1</a></li>";
				$pagination.= "<li><a href=\"$targetpage?page=$lastpage\">$lastpage</a></li>";		
			}
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<li><a href=\"$targetpage?page=1\">1</a></li>";
				$pagination.= "<li><a href=\"$targetpage?page=2\">2</a></li>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<li class=\"active\"><a href=\"#\">$counter</a></li>";
					else
						$pagination.= "<li><a href=\"$targetpage?page=$counter\">$counter</a></li>";					
				}
				$pagination.= "...";
				$pagination.= "<li><a href=\"$targetpage?page=$lpm1\">$lpm1</a></li>";
				$pagination.= "<li><a href=\"$targetpage?page=$lastpage\">$lastpage</a></li>";		
			}
			else
			{
				$pagination.= "<li><a href=\"$targetpage?page=1\">1</a></li>";
				$pagination.= "<li><a href=\"$targetpage?page=2\">2</a></li>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<li class=\"active\"><a href=\"#\">$counter</a></li>";
					else
						$pagination.= "<li><a href=\"$targetpage?page=$counter\">$counter</a></li>";					
				}
			}
		}
		if ($page < $counter - 1) 
			$pagination.= "<li><a href=\"$targetpage?page=$next\">&raquo;</a></li>";
		else
			$pagination.= "<li class=\"disabled\"><a href=\"#\">&raquo;</a></li>";
		$pagination.= "</ul>\n";		
	}
	$q= $mysqli->query("SELECT * FROM payments WHERE status=1 ORDER BY id DESC limit $start,$limit");
	$numr = mysqli_num_rows($q);
	if ($numr==0)
	{
	echo '<div class="alert alert-danger">There are currently no completed payments.</div>';
	}
	if ($numr>0)
	{
	?>
        <thead>
            <tr>
				<th>Date</th>
                <th>Refferal ID</th>
                <th>Paypal ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Manage</th>
            </tr>
        </thead>
        <tbody>
   <?php
	}
	while($Row=mysqli_fetch_assoc($q)){
	$Date	= $Row['date'];
	$ReffId = $Row['reffid'];
	$Amount = $Row['amount'];
	$Paypal = $Row['paypal'];
	$Stat = $Row['status'];
	$Status = str_replace('1', 'Success', $Stat)
?>        
            <tr class="btnDelete" data-id="<?php echo $Row['id'];?>">
			<td><?php echo $Date;?></td>
<td><?php echo $ReffId;?></td>
<td><?php echo $Paypal;?></td>
<td> <i class="fa fa-paypal" aria-hidden="true"></i> $<?php echo $Amount;?></td>
<td><span class="badge badge-success bg-color-green"><?php echo $Status;?></span></td>
                <td>
               <button  title="Delete" class="btn btn-danger btnDelete"><i class="fa fa-trash" aria-hidden="true"></i></button>
               <button  title="Pending" class="btn btn-warning btnDisapprove"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i></button>
               
                </td>
            </tr>
<?php } ?>
        </tbody>
    </table></div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title">Confirmation</h4>
            </div>
            <div class="modal-body">
				<p>Are you sure you want to delete this payment?</p>
                <p class="text-warning"><small>This action cannot be undone.</small></p>		
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="btnDelteYes">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="DisapproveModal" tabindex="-1" role="dialog" aria-labelledby="DisapproveModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title">Confirmation</h4>
            </div>
            <div class="modal-body">
                 <p> Are you sure you want to change the status of this payment to be pending?</p>
				 <p class="text-info"><small>You can complete this by navigating to Payments > Pending.</small></p>	
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="btnDisapproveYes">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<div class="text-center"><?php echo $pagination;?></div>
</div>
</div>
</div>
</div>
<?php include("act/_footer.php");?>