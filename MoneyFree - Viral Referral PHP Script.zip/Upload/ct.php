<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
session_start();
$_SESSION = array();
include("include/simple-php-captcha.php");
$_SESSION['captcha'] = simple_php_captcha();
include("include/main.php");
include("include/header.php");
?>
<section class="content text-left">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="clearfix"></div>
<div class="row">
<div class="col-md-8" style="margin-bottom:3em;"><h4>Contact us</h4>
<p>We will be very happy to help you.</p>
<div id="output"></div>
<form id="ContactForm" action="_sm.php" method="post">
<div class="row">
    <div class="col">
      <input name="inputYourname" id="inputYourname" type="text" class="form-control" placeholder="Your Name">
    </div>
    <div class="col">
      <input name="inputEmail" id="inputEmail"  type="text" class="form-control" placeholder="Your Email Adress">
    </div>
</div>
<p></p>
<div class="clearfix"></div>
<div class="form-group">
<input type="text" class="form-control" name="inputSubject" id="inputSubject" placeholder="Subject">
</div>
<div class="form-group">
<textarea class="form-control" id="inputMessage" name="inputMessage" rows="3" placeholder="Your Message"></textarea>
</div> 

<div class="form-group">
<?php
        echo '<img src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA code">';

        ?>  
<input style="clear:both;margin-top:8px;width:160px" type="text" class="form-control" name="inputCaptcha" id="inputCaptcha" placeholder="Enter Captcha code">
</div>  
<button type="submit" id="submitButton" class="btn btn-primary">Send</button>
</form>
</div>
<div class="col-md-4">
<?php include ('_ucp.php');?>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<?php include("include/footer.php");?>