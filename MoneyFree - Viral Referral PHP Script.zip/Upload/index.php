<?php 
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
error_reporting(E_ALL);
ini_set('display_errors', '1');
include("include/main.php");
include("include/header.php");
?>
<!-- Section FAQ -->
<section class="content text-left">
      <div class="container">
        <div class="row">
 <div class="col-lg-12">
     <?php echo $error; ?>
     <div class="clearfix"></div>
     <div class="row">
	<div class="col-md-4" style="margin-bottom:3em;">
<?php include ('_ucp.php');?>
	</div>
	<div class="col-md-8">
		<h4>Easy Ways To Make Money Quickly</h4>
		<p class="lead">Making money online has never been easier. Unlike others here you can make money up to $200/day just by sharing your link.No registration required! We will pay you $<?php echo $Rec;?> for every 100 valid visitors to your link.</p>

		<h4>How It Works?</h4>
		<p class="lead">
You simply copy your URL ID. Invite other people to visit your URL ID. We will pay you every time your URL is visited by someone else.</p>

		<h4>When will I get paid?</h4>
		<p class="lead">You can request payment when your balance has reached the minimum withdrawal threshold.Payment will be sent directly to your Paypal account.</p>
		<p class="text-right"><a class="btn btn-info btn-sm" href="/page/faq">Learn more &rarr;</a></p>
	</div>
</div>
<?php if (!empty($BannerCodeContent)){ ?>
<div class="azcont">	<?php echo $BannerCodeContent;?></div>
<?	}?>  
</div>
</div>
</div>
</section>
<!--\ Section Content -->

<!-- Separator Line -->
<hr style="max-width:80%"/>
<!--\ Separator Line  -->

<!-- Section Payout -->
<section class="content text-left">
      <div class="container">
        <div class="row">
 <div class="col-lg-12">
     <h3 class="text-center">Recent Payout</h3>
     <br/>
     <div class="clearfix"></div>
<div class="table-responsive">
<table class="table table-bordered table-striped table-hover">	
<?php
if($PaymentSql = $mysqli->query("SELECT * FROM payments ORDER BY id DESC LIMIT 0, 10")){
$CountRows = mysqli_num_rows($PaymentSql);
if (empty($CountRows)) {
$Class='hide';
} elseif (!empty($CountRows))
{
$Class='';
}
?>
<thead class="<?php echo $Class;?> thead-dark">
    <tr>
      <th scope="col">Date</th>
      <th scope="col">URL ID</th>
      <th scope="col">Amount</th>
       <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
  <?php while ($PaymentRow = mysqli_fetch_array($PaymentSql)){
    $Date	= $PaymentRow['date'];
	$ReffId = $PaymentRow['reffid'];
	$Amount = $PaymentRow['amount'];
	$Stat   = $PaymentRow['status'];
	if($Stat==0){
	$Status = '<i class="fas fa-exclamation-circle"></i> Pending';
	$StatusClass ='warning';
	}
	elseif($Stat==1){
	$Status = '<i class="fas fa-check-circle"></i> Success!'; 
	$StatusClass ='success';	
	}
?>
<tr>
      <th scope="row" class="thh"><?php echo $Date;?></th>
      <td  class="tdd">#<?php echo $ReffId;?></td>
      <td  class="tdd"><i class="fab fa-paypal"></i> $<?php echo $Amount;?></td> <td  class="tdd"><span class="badge badge-<?php echo $StatusClass;?>"><?php echo $Status;?></span></td>
</tr>
    <?php     
	}?> 
<?php $PaymentSql->close();
}else{
     printf("Error: %s\n", $mysqli->error);?>
 <?php }
if($CountRows==0){
?><div class="alert alert-danger text-center">There are currently no completed payments.</div><?php }?>
</tbody></table> </div>
</div>
</div>
</div>
</section> 
<!--\ Section Payout -->

<!-- Separator Line -->
<hr style="max-width:80%"/>
<!--\ Separator Line -->

<!-- Section Features Icon -->
<section class="features-icons bg-white text-center">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
              <div class="features-icons-icon d-flex">
                <i class="icon-link m-auto text-primary"></i>
              </div>
              <h3>Copy Your Link</h3>
              <p class="lead mb-0">Copy your referral link. Use this link to invite more people.</p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
              <div class="features-icons-icon d-flex">
                <i class="icon-share m-auto text-primary"></i>
              </div>
              <h3>Share With Anyone</h3>
              <p class="lead mb-0">Tell anyone to visit your link. Spread your link without spam.</p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="features-icons-item mx-auto mb-0 mb-lg-3">
              <div class="features-icons-icon d-flex">
                <i class="icon-paypal m-auto text-primary"></i>
              </div>
              <h3>Make Real Money</h3>
              <p class="lead mb-0">Convert your visitors into real money to your PayPal account.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
<!--\ Section Features Icon -->
<?php include("include/footer.php");?>