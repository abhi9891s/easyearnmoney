<?php
/*
.---------------------------------------------------------------------------.
|                                                                           |
|  Software: MoneyFree - Viral Referral PHP Script                          |
|  Version : 1.0.0                                                          |
|  Author  : Edri Yanto                                                     |
|  Email   : edri.pali@gmail.com                                            |
|  Site    : http://phpscripts.cc                                           |
|  Date    : October 16, 2018                                               |
|                                                                           |
'---------------------------------------------------------------------------'
*/
?>
<!-- User Info -->
<div class="card">
  <div class="card-body">
   <ul class="list-group list-group-flush">
 <li class="list-group-item"><i class="fas fa-link"></i> URL ID: <span class="badge badge-primary"><?php echo $ref; ?></span></li>
  <li class="list-group-item"><i class="fas fa-chart-bar"></i> Visitors: <span class="badge badge-info"><?php echo $hits; ?></span></li>
  <li class="list-group-item"><i class="fas fa-coins"></i> Current Balance: <span class="badge badge-success">$<?php echo $Bal; ?></span></li>
   <li class="list-group-item"><i class="fas fa-funnel-dollar"></i> Last Payout: <span class="badge badge-danger">$<?php echo $lPayout; ?></span></li>
</ul><div id="progress" class="graph"><div id="bar" style="width:<?php if($percent < 100){?><?php echo $setpercent;?><?php } else { ?>100<?php }?>%"><p><span class="percent"><?php if($percent < 100){?><?php echo $textpercent;?><?php } else { ?>100<?php }?>%</span> withdrawal threshold...</p></div></div>
 
 <!-- Simple Social Share -->
 <div class="social-share">
 <!-- Facebook Share Button -->
<a target="_blank" class="btns facebook" href="https://facebook.com/sharer.php?t=<?php echo $PageTitle;?>&u=<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>"><i class="fab fa-facebook-f"></i> Share</a>
<!-- Twitter Share Button -->
<a target="_blank" class="btns twitter" href="https://twitter.com/intent/tweet?text=<?php echo $PageTitle;?>&url=<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>"><i class="fab fa-twitter"></i> Tweet</a>
<!-- Googple Plus Share Button -->
<a target="_blank" class="btns gplus" href="https://plus.google.com/share?url=<?php echo $SiteUrl?>/<?php echo $PageUrl; ?><?php echo $referlink;?>"><i class="fab fa-google-plus-g"></i> Share</a>
</div>
 <!--\ Simple Social Share -->
     <?php  if($Bal >$Payout || $Bal == $Payout){	?><a target="_blank" href="/payout" class="btn btn-primary btn-lg btn-block"><i class="fab fa-paypal"></i> Withdraw</a>
	<?php  } else {?><a href="#" class="btn btn-info btn-lg btn-block" data-toggle="modal" data-target="#payout"><i class="fab fa-paypal"></i> Withdraw</a>
  <p class="text-center" style="color:#bec5b8;font-size:15px;margin-bottom:0;margin-top:1em"><small><i class="far fa-lightbulb"></i> You currently have balance of $<?php echo $Bal;?>, after your balance reaches minimum of $<?php echo $Payout;?> you can make  withdrawal to your Paypal account. Remaining balance needed is $<?php echo $Proc;?> or more.</small></p>
<?  } ?>
  </div>
</div>
<!--\ User Info -->
<?php ?>